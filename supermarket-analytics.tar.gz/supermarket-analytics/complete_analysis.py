"""
Complete Supermarket Sales Data Analytics Pipeline
Including Machine Learning and Deep Learning Models
Dataset: Online Retail Transaction Data (541K+ records)
"""

import warnings
warnings.filterwarnings('ignore')

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
import os

# Machine Learning
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import xgboost as xgb

# Deep Learning
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
from tensorflow.keras.callbacks import EarlyStopping

# Set random seeds for reproducibility
np.random.seed(42)
tf.random.set_seed(42)

# Create output directories
os.makedirs('outputs', exist_ok=True)
os.makedirs('outputs/eda', exist_ok=True)
os.makedirs('outputs/models', exist_ok=True)
os.makedirs('outputs/predictions', exist_ok=True)

# Configure plotting
plt.style.use('seaborn-v0_8-darkgrid')
sns.set_palette("husl")

print("="*80)
print("SUPERMARKET SALES DATA ANALYTICS PIPELINE")
print("="*80)

# ============================================================================
# STEP 1: DATA LOADING & EXPLORATION
# ============================================================================
print("\n" + "="*80)
print("STEP 1: DATA LOADING & EXPLORATION")
print("="*80)

# Load dataset
df = pd.read_csv('supermarket_data.csv', encoding='latin-1')
print(f"\n✓ Dataset loaded successfully!")
print(f"  Shape: {df.shape[0]:,} rows × {df.shape[1]} columns")

# Sample for faster processing (use 100K rows)
SAMPLE_SIZE = 100000
if len(df) > SAMPLE_SIZE:
    df = df.sample(n=SAMPLE_SIZE, random_state=42).reset_index(drop=True)
    print(f"  Sampled to: {len(df):,} rows for efficient processing")

# Display first 10 rows
print("\n" + "-"*80)
print("First 10 rows of the dataset:")
print("-"*80)
print(df.head(10).to_string())

# Dataset info
print("\n" + "-"*80)
print("Dataset Information:")
print("-"*80)
print(f"Total entries: {len(df):,}")
print(f"\nColumn details:")
df.info()

# Missing values
print("\n" + "-"*80)
print("Missing Values Analysis:")
print("-"*80)
missing = df.isnull().sum()
missing_pct = (missing / len(df) * 100).round(2)
missing_df = pd.DataFrame({
    'Missing Count': missing,
    'Percentage': missing_pct
})
print(missing_df[missing_df['Missing Count'] > 0])

# Descriptive statistics
print("\n" + "-"*80)
print("Descriptive Statistics (Numerical Columns):")
print("-"*80)
print(df.describe().to_string())

# Identify feature types
numerical_cols = df.select_dtypes(include=[np.number]).columns.tolist()
categorical_cols = df.select_dtypes(include=['object']).columns.tolist()

print("\n" + "-"*80)
print("Feature Classification:")
print("-"*80)
print(f"Numerical features ({len(numerical_cols)}): {numerical_cols}")
print(f"Categorical features ({len(categorical_cols)}): {categorical_cols}")

# ============================================================================
# STEP 2: DATA CLEANING & PREPROCESSING
# ============================================================================
print("\n" + "="*80)
print("STEP 2: DATA CLEANING & PREPROCESSING")
print("="*80)

# Create a copy for processing
df_processed = df.copy()

# Calculate Total (Price * Quantity)
df_processed['Total'] = df_processed['Price'] * df_processed['Quantity']
print(f"\n✓ Created 'Total' column (Price × Quantity)")

# Handle missing values
print(f"\n✓ Handling missing values...")
df_processed['Description'].fillna('UNKNOWN', inplace=True)
df_processed['Customer ID'].fillna(0, inplace=True)

# Remove rows with negative quantities or prices
initial_rows = len(df_processed)
df_processed = df_processed[(df_processed['Quantity'] > 0) & (df_processed['Price'] > 0)]
removed_rows = initial_rows - len(df_processed)
print(f"  Removed {removed_rows:,} rows with negative/zero Quantity or Price")
print(f"  Remaining rows: {len(df_processed):,}")

# Convert InvoiceDate to datetime
df_processed['InvoiceDate'] = pd.to_datetime(df_processed['InvoiceDate'], format='%d/%m/%y %H:%M')
print(f"\n✓ Converted 'InvoiceDate' to datetime format")

# Extract temporal features
df_processed['Year'] = df_processed['InvoiceDate'].dt.year
df_processed['Month'] = df_processed['InvoiceDate'].dt.month
df_processed['Day'] = df_processed['InvoiceDate'].dt.day
df_processed['Hour'] = df_processed['InvoiceDate'].dt.hour
df_processed['DayOfWeek'] = df_processed['InvoiceDate'].dt.dayofweek
df_processed['Quarter'] = df_processed['InvoiceDate'].dt.quarter
print(f"✓ Extracted temporal features: Year, Month, Day, Hour, DayOfWeek, Quarter")

# Create product category from description
def categorize_product(desc):
    desc_upper = str(desc).upper()
    if any(word in desc_upper for word in ['HEART', 'LOVE', 'CUPID']):
        return 'Romantic'
    elif any(word in desc_upper for word in ['CHRISTMAS', 'XMAS', 'SANTA']):
        return 'Christmas'
    elif any(word in desc_upper for word in ['VINTAGE', 'RETRO']):
        return 'Vintage'
    elif any(word in desc_upper for word in ['PARTY', 'CELEBRATION']):
        return 'Party'
    elif any(word in desc_upper for word in ['KITCHEN', 'COOK', 'JAR']):
        return 'Kitchen'
    elif any(word in desc_upper for word in ['LIGHT', 'CANDLE', 'LAMP']):
        return 'Lighting'
    elif any(word in desc_upper for word in ['BAG', 'CASE', 'HOLDER']):
        return 'Storage'
    elif any(word in desc_upper for word in ['DECOR', 'WALL', 'ORNAMENT']):
        return 'Decoration'
    else:
        return 'General'

df_processed['ProductCategory'] = df_processed['Description'].apply(categorize_product)
print(f"✓ Created 'ProductCategory' feature")

# Label Encoding for categorical variables
print(f"\n✓ Encoding categorical variables...")
label_encoders = {}
categorical_features = ['Country', 'ProductCategory']

for col in categorical_features:
    le = LabelEncoder()
    df_processed[f'{col}_Encoded'] = le.fit_transform(df_processed[col].astype(str))
    label_encoders[col] = le
    print(f"  Encoded '{col}' → '{col}_Encoded' ({len(le.classes_)} unique values)")

# Create customer segment
customer_totals = df_processed.groupby('Customer ID')['Total'].sum()
df_processed['CustomerSegment'] = df_processed['Customer ID'].map(customer_totals)
df_processed['CustomerSegment_Encoded'] = pd.qcut(df_processed['CustomerSegment'], 
                                                     q=3, 
                                                     labels=[0, 1, 2],
                                                     duplicates='drop').astype(int)
print(f"✓ Created 'CustomerSegment' feature")

# Select features for modeling
feature_cols = ['Quantity', 'Price', 'Year', 'Month', 'Day', 'Hour', 'DayOfWeek', 
                'Quarter', 'Country_Encoded', 'ProductCategory_Encoded', 
                'CustomerSegment_Encoded']

X = df_processed[feature_cols].copy()
y = df_processed['Total'].copy()

print(f"\n✓ Feature matrix X: {X.shape}")
print(f"✓ Target variable y: {y.shape}")

# Scale features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)
X_scaled = pd.DataFrame(X_scaled, columns=feature_cols, index=X.index)
print(f"\n✓ Features scaled using StandardScaler")
print(f"\n✓ Preprocessing complete! Final dataset shape: {df_processed.shape}")

# ============================================================================
# STEP 3: EXPLORATORY DATA ANALYSIS (EDA)
# ============================================================================
print("\n" + "="*80)
print("STEP 3: EXPLORATORY DATA ANALYSIS (EDA)")
print("="*80)

print("\n✓ Generating EDA visualizations...")

# Plot 1: Distribution of numerical features
fig, axes = plt.subplots(2, 2, figsize=(16, 12))

axes[0, 0].hist(df_processed['Total'], bins=100, edgecolor='black', alpha=0.7)
axes[0, 0].set_title('Distribution of Total Sales', fontsize=14, fontweight='bold')
axes[0, 0].set_xlabel('Total Sales Amount')
axes[0, 0].set_ylabel('Frequency')
axes[0, 0].axvline(df_processed['Total'].mean(), color='red', linestyle='--', 
                    label=f"Mean: ${df_processed['Total'].mean():.2f}")
axes[0, 0].legend()

axes[0, 1].hist(df_processed['Quantity'], bins=50, edgecolor='black', alpha=0.7, color='green')
axes[0, 1].set_title('Distribution of Quantity', fontsize=14, fontweight='bold')
axes[0, 1].set_xlabel('Quantity')
axes[0, 1].set_ylabel('Frequency')

axes[1, 0].hist(df_processed['Price'], bins=100, edgecolor='black', alpha=0.7, color='orange')
axes[1, 0].set_title('Distribution of Price', fontsize=14, fontweight='bold')
axes[1, 0].set_xlabel('Price')
axes[1, 0].set_ylabel('Frequency')

monthly_sales = df_processed.groupby(['Year', 'Month'])['Total'].sum().reset_index()
axes[1, 1].plot(range(len(monthly_sales)), monthly_sales['Total'], marker='o', linewidth=2)
axes[1, 1].set_title('Total Sales Over Time', fontsize=14, fontweight='bold')
axes[1, 1].set_xlabel('Time Period')
axes[1, 1].set_ylabel('Total Sales')
axes[1, 1].grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig('outputs/eda/01_distributions.png', dpi=300, bbox_inches='tight')
plt.close()
print(f"  Saved: outputs/eda/01_distributions.png")

# Plot 2: Categorical Analysis
fig, axes = plt.subplots(2, 2, figsize=(16, 12))

country_sales = df_processed.groupby('Country')['Total'].sum().sort_values(ascending=False).head(10)
axes[0, 0].barh(country_sales.index, country_sales.values, color='skyblue', edgecolor='black')
axes[0, 0].set_title('Top 10 Countries by Total Sales', fontsize=14, fontweight='bold')
axes[0, 0].set_xlabel('Total Sales')
axes[0, 0].invert_yaxis()

category_sales = df_processed.groupby('ProductCategory')['Total'].sum().sort_values(ascending=False)
axes[0, 1].bar(category_sales.index, category_sales.values, color='lightgreen', edgecolor='black')
axes[0, 1].set_title('Sales by Product Category', fontsize=14, fontweight='bold')
axes[0, 1].set_xlabel('Product Category')
axes[0, 1].set_ylabel('Total Sales')
axes[0, 1].tick_params(axis='x', rotation=45)

hourly_sales = df_processed.groupby('Hour')['Total'].sum()
axes[1, 0].plot(hourly_sales.index, hourly_sales.values, marker='o', linewidth=2, color='purple')
axes[1, 0].set_title('Sales by Hour of Day', fontsize=14, fontweight='bold')
axes[1, 0].set_xlabel('Hour')
axes[1, 0].set_ylabel('Total Sales')
axes[1, 0].grid(True, alpha=0.3)

dow_names = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
dow_sales = df_processed.groupby('DayOfWeek')['Total'].sum()
dow_labels = [dow_names[i] if i < len(dow_names) else f'Day{i}' for i in dow_sales.index]
axes[1, 1].bar(dow_labels, dow_sales.values, color='coral', edgecolor='black')
axes[1, 1].set_title('Sales by Day of Week', fontsize=14, fontweight='bold')
axes[1, 1].set_xlabel('Day of Week')
axes[1, 1].set_ylabel('Total Sales')

plt.tight_layout()
plt.savefig('outputs/eda/02_categorical_analysis.png', dpi=300, bbox_inches='tight')
plt.close()
print(f"  Saved: outputs/eda/02_categorical_analysis.png")

# Plot 3: Top products
fig, axes = plt.subplots(1, 2, figsize=(16, 6))

top_products_qty = df_processed.groupby('Description')['Quantity'].sum().sort_values(ascending=False).head(15)
axes[0].barh(range(len(top_products_qty)), top_products_qty.values, color='teal', edgecolor='black')
axes[0].set_yticks(range(len(top_products_qty)))
axes[0].set_yticklabels([desc[:40] for desc in top_products_qty.index], fontsize=9)
axes[0].set_title('Top 15 Products by Quantity Sold', fontsize=14, fontweight='bold')
axes[0].set_xlabel('Total Quantity')
axes[0].invert_yaxis()

top_products_rev = df_processed.groupby('Description')['Total'].sum().sort_values(ascending=False).head(15)
axes[1].barh(range(len(top_products_rev)), top_products_rev.values, color='gold', edgecolor='black')
axes[1].set_yticks(range(len(top_products_rev)))
axes[1].set_yticklabels([desc[:40] for desc in top_products_rev.index], fontsize=9)
axes[1].set_title('Top 15 Products by Revenue', fontsize=14, fontweight='bold')
axes[1].set_xlabel('Total Revenue')
axes[1].invert_yaxis()

plt.tight_layout()
plt.savefig('outputs/eda/03_top_products.png', dpi=300, bbox_inches='tight')
plt.close()
print(f"  Saved: outputs/eda/03_top_products.png")

# Plot 4: Correlation heatmap
plt.figure(figsize=(12, 10))
correlation_matrix = X.corr()
sns.heatmap(correlation_matrix, annot=True, fmt='.2f', cmap='coolwarm', 
            square=True, linewidths=1, cbar_kws={"shrink": 0.8})
plt.title('Feature Correlation Heatmap', fontsize=16, fontweight='bold', pad=20)
plt.tight_layout()
plt.savefig('outputs/eda/04_correlation_heatmap.png', dpi=300, bbox_inches='tight')
plt.close()
print(f"  Saved: outputs/eda/04_correlation_heatmap.png")

# Plot 5: Box plots
fig, axes = plt.subplots(1, 3, figsize=(18, 6))

axes[0].boxplot(df_processed['Quantity'], vert=True)
axes[0].set_title('Quantity Box Plot', fontsize=14, fontweight='bold')
axes[0].set_ylabel('Quantity')

axes[1].boxplot(df_processed['Price'], vert=True)
axes[1].set_title('Price Box Plot', fontsize=14, fontweight='bold')
axes[1].set_ylabel('Price')

axes[2].boxplot(df_processed['Total'], vert=True)
axes[2].set_title('Total Sales Box Plot', fontsize=14, fontweight='bold')
axes[2].set_ylabel('Total Sales')

plt.tight_layout()
plt.savefig('outputs/eda/05_boxplots.png', dpi=300, bbox_inches='tight')
plt.close()
print(f"  Saved: outputs/eda/05_boxplots.png")

# Plot 6: Monthly trends
monthly_stats = df_processed.groupby(['Year', 'Month']).agg({
    'Total': 'sum',
    'Quantity': 'sum',
    'Invoice': 'nunique'
}).reset_index()
monthly_stats.columns = ['Year', 'Month', 'TotalSales', 'TotalQuantity', 'UniqueInvoices']

fig, axes = plt.subplots(3, 1, figsize=(14, 12))

axes[0].plot(range(len(monthly_stats)), monthly_stats['TotalSales'], 
             marker='o', linewidth=2, color='blue')
axes[0].set_title('Monthly Total Sales Trend', fontsize=14, fontweight='bold')
axes[0].set_ylabel('Total Sales')
axes[0].grid(True, alpha=0.3)

axes[1].plot(range(len(monthly_stats)), monthly_stats['TotalQuantity'], 
             marker='s', linewidth=2, color='green')
axes[1].set_title('Monthly Total Quantity Trend', fontsize=14, fontweight='bold')
axes[1].set_ylabel('Total Quantity')
axes[1].grid(True, alpha=0.3)

axes[2].plot(range(len(monthly_stats)), monthly_stats['UniqueInvoices'], 
             marker='^', linewidth=2, color='red')
axes[2].set_title('Monthly Unique Invoices Trend', fontsize=14, fontweight='bold')
axes[2].set_ylabel('Unique Invoices')
axes[2].set_xlabel('Month')
axes[2].grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig('outputs/eda/06_monthly_trends.png', dpi=300, bbox_inches='tight')
plt.close()
print(f"  Saved: outputs/eda/06_monthly_trends.png")

print(f"\n✓ EDA visualizations complete! (6 plots generated)")

# ============================================================================
# STEP 4: MACHINE LEARNING MODEL TRAINING
# ============================================================================
print("\n" + "="*80)
print("STEP 4: MACHINE LEARNING MODEL TRAINING")
print("="*80)

# Split data
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, 
                                                      test_size=0.2, 
                                                      random_state=42)
print(f"\n✓ Data split:")
print(f"  Training set: {X_train.shape[0]:,} samples")
print(f"  Test set: {X_test.shape[0]:,} samples")

ml_results = {}

# Model 1: Linear Regression
print(f"\n" + "-"*80)
print("Training Model 1: Linear Regression")
print("-"*80)
lr_model = LinearRegression()
lr_model.fit(X_train, y_train)
y_pred_lr = lr_model.predict(X_test)

mae_lr = mean_absolute_error(y_test, y_pred_lr)
mse_lr = mean_squared_error(y_test, y_pred_lr)
rmse_lr = np.sqrt(mse_lr)
r2_lr = r2_score(y_test, y_pred_lr)

ml_results['Linear Regression'] = {
    'MAE': mae_lr, 'MSE': mse_lr, 'RMSE': rmse_lr, 'R2': r2_lr,
    'predictions': y_pred_lr
}

print(f"✓ Results: MAE=${mae_lr:.4f}, RMSE=${rmse_lr:.4f}, R²={r2_lr:.4f}")

# Model 2: Random Forest
print(f"\n" + "-"*80)
print("Training Model 2: Random Forest Regressor")
print("-"*80)
rf_model = RandomForestRegressor(n_estimators=100, max_depth=20,
                                  min_samples_split=10, random_state=42, n_jobs=-1)
rf_model.fit(X_train, y_train)
y_pred_rf = rf_model.predict(X_test)

mae_rf = mean_absolute_error(y_test, y_pred_rf)
mse_rf = mean_squared_error(y_test, y_pred_rf)
rmse_rf = np.sqrt(mse_rf)
r2_rf = r2_score(y_test, y_pred_rf)

ml_results['Random Forest'] = {
    'MAE': mae_rf, 'MSE': mse_rf, 'RMSE': rmse_rf, 'R2': r2_rf,
    'predictions': y_pred_rf, 'feature_importance': rf_model.feature_importances_
}

print(f"✓ Results: MAE=${mae_rf:.4f}, RMSE=${rmse_rf:.4f}, R²={r2_rf:.4f}")

# Model 3: XGBoost
print(f"\n" + "-"*80)
print("Training Model 3: XGBoost Regressor")
print("-"*80)
xgb_model = xgb.XGBRegressor(n_estimators=100, max_depth=10,
                              learning_rate=0.1, random_state=42, n_jobs=-1)
xgb_model.fit(X_train, y_train)
y_pred_xgb = xgb_model.predict(X_test)

mae_xgb = mean_absolute_error(y_test, y_pred_xgb)
mse_xgb = mean_squared_error(y_test, y_pred_xgb)
rmse_xgb = np.sqrt(mse_xgb)
r2_xgb = r2_score(y_test, y_pred_xgb)

ml_results['XGBoost'] = {
    'MAE': mae_xgb, 'MSE': mse_xgb, 'RMSE': rmse_xgb, 'R2': r2_xgb,
    'predictions': y_pred_xgb, 'feature_importance': xgb_model.feature_importances_
}

print(f"✓ Results: MAE=${mae_xgb:.4f}, RMSE=${rmse_xgb:.4f}, R²={r2_xgb:.4f}")

# Compare ML models
print(f"\n" + "-"*80)
print("ML Model Comparison:")
print("-"*80)
comparison_df = pd.DataFrame({
    'Model': list(ml_results.keys()),
    'MAE': [ml_results[m]['MAE'] for m in ml_results.keys()],
    'RMSE': [ml_results[m]['RMSE'] for m in ml_results.keys()],
    'R²': [ml_results[m]['R2'] for m in ml_results.keys()]
})
print(comparison_df.to_string(index=False))

best_ml_model = comparison_df.loc[comparison_df['R²'].idxmax(), 'Model']
print(f"\n🏆 Best ML Model: {best_ml_model} (R² = {comparison_df['R²'].max():.4f})")

# Plot ML predictions
fig, axes = plt.subplots(1, 3, figsize=(18, 5))

for idx, (model_name, results) in enumerate(ml_results.items()):
    y_pred = results['predictions']
    r2 = results['R2']
    
    axes[idx].scatter(y_test, y_pred, alpha=0.3, s=10)
    axes[idx].plot([y_test.min(), y_test.max()], 
                   [y_test.min(), y_test.max()], 
                   'r--', lw=2, label='Perfect Prediction')
    axes[idx].set_xlabel('Actual Total Sales', fontsize=12)
    axes[idx].set_ylabel('Predicted Total Sales', fontsize=12)
    axes[idx].set_title(f'{model_name}\n(R² = {r2:.4f})', fontsize=12, fontweight='bold')
    axes[idx].legend()
    axes[idx].grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig('outputs/models/ml_predictions_comparison.png', dpi=300, bbox_inches='tight')
plt.close()
print(f"\n✓ Saved: outputs/models/ml_predictions_comparison.png")

# ============================================================================
# STEP 5: DEEP LEARNING MODEL TRAINING
# ============================================================================
print("\n" + "="*80)
print("STEP 5: DEEP LEARNING MODEL TRAINING")
print("="*80)

print(f"\n✓ Building Deep Neural Network...")
dl_model = keras.Sequential([
    layers.Input(shape=(X_train.shape[1],)),
    layers.Dense(128, activation='relu', name='hidden_1'),
    layers.Dropout(0.2),
    layers.Dense(64, activation='relu', name='hidden_2'),
    layers.Dropout(0.2),
    layers.Dense(32, activation='relu', name='hidden_3'),
    layers.Dense(1, name='output')
])

dl_model.compile(optimizer='adam', loss='mse', metrics=['mae'])

print(f"\n✓ Model Architecture:")
dl_model.summary()

early_stop = EarlyStopping(monitor='val_loss', patience=10, restore_best_weights=True)

print(f"\n✓ Training Deep Learning model...")
history = dl_model.fit(
    X_train, y_train,
    validation_split=0.2,
    epochs=100,
    batch_size=256,
    callbacks=[early_stop],
    verbose=0
)

print(f"✓ Training complete! (Epochs: {len(history.history['loss'])})")

y_pred_dl = dl_model.predict(X_test, verbose=0).flatten()

mae_dl = mean_absolute_error(y_test, y_pred_dl)
mse_dl = mean_squared_error(y_test, y_pred_dl)
rmse_dl = np.sqrt(mse_dl)
r2_dl = r2_score(y_test, y_pred_dl)

print(f"\n✓ Results: MAE=${mae_dl:.4f}, RMSE=${rmse_dl:.4f}, R²={r2_dl:.4f}")

# Plot training history
fig, axes = plt.subplots(1, 2, figsize=(14, 5))

axes[0].plot(history.history['loss'], label='Training Loss', linewidth=2)
axes[0].plot(history.history['val_loss'], label='Validation Loss', linewidth=2)
axes[0].set_xlabel('Epoch', fontsize=12)
axes[0].set_ylabel('Loss (MSE)', fontsize=12)
axes[0].set_title('Deep Learning Model - Loss Curves', fontsize=14, fontweight='bold')
axes[0].legend()
axes[0].grid(True, alpha=0.3)

axes[1].plot(history.history['mae'], label='Training MAE', linewidth=2)
axes[1].plot(history.history['val_mae'], label='Validation MAE', linewidth=2)
axes[1].set_xlabel('Epoch', fontsize=12)
axes[1].set_ylabel('MAE', fontsize=12)
axes[1].set_title('Deep Learning Model - MAE Curves', fontsize=14, fontweight='bold')
axes[1].legend()
axes[1].grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig('outputs/models/dl_training_curves.png', dpi=300, bbox_inches='tight')
plt.close()
print(f"\n✓ Saved: outputs/models/dl_training_curves.png")

# Plot DL predictions
plt.figure(figsize=(10, 6))
plt.scatter(y_test, y_pred_dl, alpha=0.3, s=10)
plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 
         'r--', lw=2, label='Perfect Prediction')
plt.xlabel('Actual Total Sales', fontsize=12)
plt.ylabel('Predicted Total Sales', fontsize=12)
plt.title(f'Deep Learning Model - Predictions vs Actual\n(R² = {r2_dl:.4f})', 
          fontsize=14, fontweight='bold')
plt.legend()
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig('outputs/models/dl_predictions.png', dpi=300, bbox_inches='tight')
plt.close()
print(f"✓ Saved: outputs/models/dl_predictions.png")

# ============================================================================
# STEP 6: PREDICTION & VISUALIZATION
# ============================================================================
print("\n" + "="*80)
print("STEP 6: PREDICTION & VISUALIZATION")
print("="*80)

# Compare all models
all_models_comparison = pd.DataFrame({
    'Model': list(ml_results.keys()) + ['Deep Learning'],
    'MAE': [ml_results[m]['MAE'] for m in ml_results.keys()] + [mae_dl],
    'RMSE': [ml_results[m]['RMSE'] for m in ml_results.keys()] + [rmse_dl],
    'R²': [ml_results[m]['R2'] for m in ml_results.keys()] + [r2_dl]
})

print(f"\n✓ All Models Comparison:")
print(all_models_comparison.to_string(index=False))

best_overall_model = all_models_comparison.loc[all_models_comparison['R²'].idxmax(), 'Model']
best_r2 = all_models_comparison['R²'].max()
print(f"\n🏆 Best Overall Model: {best_overall_model} (R² = {best_r2:.4f})")

# Bar chart comparison
fig, axes = plt.subplots(1, 3, figsize=(18, 5))

axes[0].bar(all_models_comparison['Model'], all_models_comparison['MAE'], 
            color=['skyblue', 'lightgreen', 'coral', 'gold'], edgecolor='black')
axes[0].set_title('Mean Absolute Error (MAE)', fontsize=14, fontweight='bold')
axes[0].set_ylabel('MAE')
axes[0].tick_params(axis='x', rotation=45)
axes[0].grid(axis='y', alpha=0.3)

axes[1].bar(all_models_comparison['Model'], all_models_comparison['RMSE'], 
            color=['skyblue', 'lightgreen', 'coral', 'gold'], edgecolor='black')
axes[1].set_title('Root Mean Squared Error (RMSE)', fontsize=14, fontweight='bold')
axes[1].set_ylabel('RMSE')
axes[1].tick_params(axis='x', rotation=45)
axes[1].grid(axis='y', alpha=0.3)

axes[2].bar(all_models_comparison['Model'], all_models_comparison['R²'], 
            color=['skyblue', 'lightgreen', 'coral', 'gold'], edgecolor='black')
axes[2].set_title('R² Score', fontsize=14, fontweight='bold')
axes[2].set_ylabel('R² Score')
axes[2].tick_params(axis='x', rotation=45)
axes[2].grid(axis='y', alpha=0.3)

plt.tight_layout()
plt.savefig('outputs/predictions/all_models_comparison.png', dpi=300, bbox_inches='tight')
plt.close()
print(f"\n✓ Saved: outputs/predictions/all_models_comparison.png")

# Feature importance
fig, axes = plt.subplots(1, 2, figsize=(16, 6))

rf_importance = pd.DataFrame({
    'Feature': feature_cols,
    'Importance': ml_results['Random Forest']['feature_importance']
}).sort_values('Importance', ascending=False)

axes[0].barh(rf_importance['Feature'], rf_importance['Importance'], 
             color='lightgreen', edgecolor='black')
axes[0].set_title('Random Forest - Feature Importance', fontsize=14, fontweight='bold')
axes[0].set_xlabel('Importance')
axes[0].invert_yaxis()

xgb_importance = pd.DataFrame({
    'Feature': feature_cols,
    'Importance': ml_results['XGBoost']['feature_importance']
}).sort_values('Importance', ascending=False)

axes[1].barh(xgb_importance['Feature'], xgb_importance['Importance'], 
             color='coral', edgecolor='black')
axes[1].set_title('XGBoost - Feature Importance', fontsize=14, fontweight='bold')
axes[1].set_xlabel('Importance')
axes[1].invert_yaxis()

plt.tight_layout()
plt.savefig('outputs/predictions/feature_importance.png', dpi=300, bbox_inches='tight')
plt.close()
print(f"✓ Saved: outputs/predictions/feature_importance.png")

# Business insights
fig, axes = plt.subplots(2, 2, figsize=(16, 12))

top_countries = df_processed.groupby('Country')['Total'].sum().sort_values(ascending=False).head(10)
axes[0, 0].bar(range(len(top_countries)), top_countries.values, 
               color='steelblue', edgecolor='black')
axes[0, 0].set_xticks(range(len(top_countries)))
axes[0, 0].set_xticklabels(top_countries.index, rotation=45, ha='right')
axes[0, 0].set_title('Top 10 Countries by Revenue', fontsize=14, fontweight='bold')
axes[0, 0].set_ylabel('Total Revenue')
axes[0, 0].grid(axis='y', alpha=0.3)

category_revenue = df_processed.groupby('ProductCategory')['Total'].sum().sort_values(ascending=False)
axes[0, 1].pie(category_revenue.values, labels=category_revenue.index, autopct='%1.1f%%',
               startangle=90, colors=sns.color_palette("husl", len(category_revenue)))
axes[0, 1].set_title('Revenue Distribution by Product Category', fontsize=14, fontweight='bold')

monthly_revenue = df_processed.groupby(['Year', 'Month'])['Total'].sum().reset_index()
axes[1, 0].plot(range(len(monthly_revenue)), monthly_revenue['Total'], 
                marker='o', linewidth=2, markersize=6, color='purple')
axes[1, 0].set_title('Monthly Revenue Trend', fontsize=14, fontweight='bold')
axes[1, 0].set_xlabel('Month Index')
axes[1, 0].set_ylabel('Total Revenue')
axes[1, 0].grid(True, alpha=0.3)

segment_names = ['Low Value', 'Medium Value', 'High Value']
segment_revenue = df_processed.groupby('CustomerSegment_Encoded')['Total'].sum()
axes[1, 1].bar(segment_names, segment_revenue.values, 
               color=['lightcoral', 'lightyellow', 'lightgreen'], edgecolor='black')
axes[1, 1].set_title('Revenue by Customer Segment', fontsize=14, fontweight='bold')
axes[1, 1].set_ylabel('Total Revenue')
axes[1, 1].grid(axis='y', alpha=0.3)

plt.tight_layout()
plt.savefig('outputs/predictions/business_insights.png', dpi=300, bbox_inches='tight')
plt.close()
print(f"✓ Saved: outputs/predictions/business_insights.png")

# ============================================================================
# STEP 7: SUMMARY REPORT
# ============================================================================
print("\n" + "="*80)
print("STEP 7: GENERATING SUMMARY REPORT")
print("="*80)

summary_report = f"""
{'='*80}
SUPERMARKET SALES DATA ANALYTICS - SUMMARY REPORT
{'='*80}

📊 DATASET OVERVIEW
{'='*80}
• Total Records Analyzed: {len(df_processed):,}
• Date Range: {df_processed['InvoiceDate'].min().strftime('%Y-%m-%d')} to {df_processed['InvoiceDate'].max().strftime('%Y-%m-%d')}
• Total Revenue: ${df_processed['Total'].sum():,.2f}
• Average Transaction: ${df_processed['Total'].mean():.2f}
• Total Unique Customers: {df_processed['Customer ID'].nunique():,}
• Total Unique Products: {df_processed['Description'].nunique():,}
• Countries Served: {df_processed['Country'].nunique()}

📈 KEY STATISTICS
{'='*80}
• Average Quantity per Transaction: {df_processed['Quantity'].mean():.2f}
• Average Price: ${df_processed['Price'].mean():.2f}
• Median Total Sales: ${df_processed['Total'].median():.2f}
• Max Single Transaction: ${df_processed['Total'].max():.2f}

🏆 MACHINE LEARNING MODELS PERFORMANCE
{'='*80}
{all_models_comparison.to_string(index=False)}

Best ML Model: {best_ml_model}
• MAE: ${ml_results[best_ml_model]['MAE']:.4f}
• RMSE: ${ml_results[best_ml_model]['RMSE']:.4f}
• R² Score: {ml_results[best_ml_model]['R2']:.4f}

🧠 DEEP LEARNING MODEL PERFORMANCE
{'='*80}
Architecture: Feedforward Neural Network
• Input Features: {X_train.shape[1]}
• Hidden Layers: 3 (128 → 64 → 32 neurons)
• Activation: ReLU
• Optimizer: Adam
• Loss Function: MSE

Results:
• MAE: ${mae_dl:.4f}
• RMSE: ${rmse_dl:.4f}
• R² Score: {r2_dl:.4f}
• Training Epochs: {len(history.history['loss'])}

🎯 BEST OVERALL MODEL: {best_overall_model}
{'='*80}
R² Score: {best_r2:.4f}

💡 KEY INSIGHTS FROM EDA
{'='*80}
1. TOP PERFORMING COUNTRY:
   • {top_countries.index[0]}: ${top_countries.values[0]:,.2f} revenue

2. TOP PRODUCT CATEGORY:
   • {category_revenue.index[0]}: ${category_revenue.values[0]:,.2f} revenue

3. PEAK SALES HOUR:
   • Hour {hourly_sales.idxmax()}: ${hourly_sales.max():,.2f} total sales

4. BEST DAY OF WEEK:
   • {dow_labels[list(dow_sales.index).index(dow_sales.idxmax())]}: ${dow_sales.max():,.2f} total sales

5. TOP 3 FEATURES (Random Forest Importance):
{chr(10).join([f'   • {rf_importance.iloc[i]["Feature"]}: {rf_importance.iloc[i]["Importance"]:.4f}' for i in range(min(3, len(rf_importance)))])}

6. TOP 3 FEATURES (XGBoost Importance):
{chr(10).join([f'   • {xgb_importance.iloc[i]["Feature"]}: {xgb_importance.iloc[i]["Importance"]:.4f}' for i in range(min(3, len(xgb_importance)))])}

📋 RECOMMENDATIONS
{'='*80}
1. CUSTOMER FOCUS:
   • Focus marketing efforts on {top_countries.index[0]} (highest revenue contributor)
   • Develop loyalty programs for high-value customer segments
   • Target customer acquisition in underperforming regions

2. PRODUCT STRATEGY:
   • Expand inventory in {category_revenue.index[0]} category (top performer)
   • Optimize stock levels based on seasonal trends
   • Bundle products from complementary categories

3. OPERATIONAL OPTIMIZATION:
   • Staff scheduling: Increase personnel during hour {hourly_sales.idxmax()}
   • Inventory management: Prepare more stock for {dow_labels[list(dow_sales.index).index(dow_sales.idxmax())]}s
   • Promotional campaigns: Target peak hours and days for maximum impact

4. PRICING STRATEGY:
   • The strong correlation between Quantity and Price suggests bundle opportunities
   • Consider volume discounts to increase average transaction size
   • Monitor price sensitivity across different customer segments

5. PREDICTIVE ANALYTICS:
   • Deploy {best_overall_model} model for real-time sales forecasting
   • Use predictions for inventory optimization and demand planning
   • Continuously retrain models with new data to maintain accuracy

6. DATA-DRIVEN DECISIONS:
   • Monitor feature importance trends to identify shifting customer preferences
   • Track model performance metrics to ensure prediction reliability
   • Integrate predictive insights into business intelligence dashboards

{'='*80}
ANALYSIS COMPLETE ✓
{'='*80}

Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

All outputs saved in:
• EDA Visualizations: outputs/eda/
• Model Results: outputs/models/
• Predictions: outputs/predictions/
{'='*80}
"""

with open('outputs/SUMMARY_REPORT.txt', 'w') as f:
    f.write(summary_report)

print(summary_report)
print(f"\n✓ Summary report saved: outputs/SUMMARY_REPORT.txt")

# Save model metrics
all_models_comparison.to_csv('outputs/model_metrics.csv', index=False)
print(f"✓ Model metrics saved: outputs/model_metrics.csv")

# Save feature importance
rf_importance.to_csv('outputs/rf_feature_importance.csv', index=False)
xgb_importance.to_csv('outputs/xgb_feature_importance.csv', index=False)
print(f"✓ Feature importance saved")

# Save predictions
predictions_df = pd.DataFrame({
    'Actual': y_test.values,
    'Linear_Regression': y_pred_lr,
    'Random_Forest': y_pred_rf,
    'XGBoost': y_pred_xgb,
    'Deep_Learning': y_pred_dl
})
predictions_df.to_csv('outputs/predictions/all_predictions.csv', index=False)
print(f"✓ Predictions saved: outputs/predictions/all_predictions.csv")

print("\n" + "="*80)
print("✅ ALL STEPS COMPLETED SUCCESSFULLY!")
print("="*80)
print(f"\nTotal visualizations generated: 11")
print(f"Total output files: 16")
print(f"\nAll results available in: /home/user/supermarket-analytics/outputs/")
print("="*80)
