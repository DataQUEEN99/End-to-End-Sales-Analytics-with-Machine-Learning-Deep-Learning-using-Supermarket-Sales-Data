#!/usr/bin/env python3
"""
Master Script: Run Complete Data Analytics Pipeline
Executes all steps from data loading to final insights
"""
import subprocess
import sys
import time
from datetime import datetime

def run_step(script_name, step_number, step_name):
    """Run a single step and handle errors"""
    print("\n" + "=" * 80)
    print(f"EXECUTING STEP {step_number}: {step_name}")
    print("=" * 80)
    print(f"Script: {script_name}")
    print(f"Started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 80 + "\n")
    
    start_time = time.time()
    
    try:
        result = subprocess.run(
            [sys.executable, script_name],
            check=True,
            capture_output=True,
            text=True
        )
        
        print(result.stdout)
        
        if result.stderr:
            print("Warnings/Errors:")
            print(result.stderr)
        
        elapsed_time = time.time() - start_time
        print(f"\n✅ Step {step_number} completed successfully in {elapsed_time:.2f} seconds")
        return True
        
    except subprocess.CalledProcessError as e:
        print(f"\n❌ Step {step_number} failed!")
        print("STDOUT:")
        print(e.stdout)
        print("\nSTDERR:")
        print(e.stderr)
        return False

def main():
    """Execute all analysis steps"""
    print("=" * 80)
    print("SUPERMARKET SALES DATA ANALYTICS PIPELINE")
    print("=" * 80)
    print(f"Started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 80)
    
    pipeline_start = time.time()
    
    steps = [
        ("step1_data_loading_exploration.py", 1, "Data Loading & Exploration"),
        ("step2_data_cleaning_preprocessing.py", 2, "Data Cleaning & Preprocessing"),
        ("step3_exploratory_data_analysis.py", 3, "Exploratory Data Analysis"),
        ("step4_machine_learning_models.py", 4, "Machine Learning Model Training"),
        ("step5_deep_learning_model.py", 5, "Deep Learning Model Training"),
        ("step6_prediction_visualization.py", 6, "Prediction & Visualization")
    ]
    
    results = []
    
    for script, step_num, step_name in steps:
        success = run_step(script, step_num, step_name)
        results.append((step_num, step_name, success))
        
        if not success:
            print(f"\n⚠️  Pipeline stopped at Step {step_num}")
            break
        
        time.sleep(1)  # Brief pause between steps
    
    pipeline_elapsed = time.time() - pipeline_start
    
    # Summary
    print("\n" + "=" * 80)
    print("PIPELINE EXECUTION SUMMARY")
    print("=" * 80)
    
    for step_num, step_name, success in results:
        status = "✅ SUCCESS" if success else "❌ FAILED"
        print(f"Step {step_num}: {step_name:50s} {status}")
    
    successful_steps = sum(1 for _, _, success in results if success)
    total_steps = len(steps)
    
    print("\n" + "=" * 80)
    print(f"Total Steps: {total_steps}")
    print(f"Successful: {successful_steps}")
    print(f"Failed: {total_steps - successful_steps}")
    print(f"Total Time: {pipeline_elapsed:.2f} seconds ({pipeline_elapsed/60:.2f} minutes)")
    print(f"Completed at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 80)
    
    if successful_steps == total_steps:
        print("\n🎉 ALL STEPS COMPLETED SUCCESSFULLY!")
        print("\nGenerated Files:")
        print("  📊 Visualizations: plots/ directory (21 plots)")
        print("  📈 ML Models: ml_models.pkl")
        print("  🧠 DL Model: dl_model.h5")
        print("  📄 Reports: *_report.txt files")
        print("  📋 Final Report: FINAL_SUMMARY_REPORT.txt")
        return 0
    else:
        print("\n⚠️  PIPELINE COMPLETED WITH ERRORS")
        return 1

if __name__ == "__main__":
    exit_code = main()
    sys.exit(exit_code)
