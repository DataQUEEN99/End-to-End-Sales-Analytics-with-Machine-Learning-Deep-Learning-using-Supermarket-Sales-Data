#!/usr/bin/env python3
"""
Step 2: Data Cleaning & Preprocessing
Handle missing values, encoding, datetime conversion, scaling
"""
import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder, StandardScaler
import warnings
warnings.filterwarnings('ignore')

print("=" * 80)
print("STEP 2: DATA CLEANING & PREPROCESSING")
print("=" * 80)

# Load the dataset
print("\n📂 Loading dataset...")
df = pd.read_csv('supermarket_sales.csv')
print(f"✓ Dataset loaded: {df.shape}")

# Create a copy for processing
df_processed = df.copy()

# 1. Handle missing values
print("\n" + "=" * 80)
print("1. HANDLING MISSING VALUES")
print("=" * 80)
missing_before = df_processed.isnull().sum().sum()
print(f"Missing values before: {missing_before}")

if missing_before > 0:
    # Fill numerical columns with median
    numerical_cols = df_processed.select_dtypes(include=['int64', 'float64']).columns
    for col in numerical_cols:
        if df_processed[col].isnull().sum() > 0:
            df_processed[col].fillna(df_processed[col].median(), inplace=True)
            print(f"  ✓ Filled {col} with median")
    
    # Fill categorical columns with mode
    categorical_cols = df_processed.select_dtypes(include=['object']).columns
    for col in categorical_cols:
        if df_processed[col].isnull().sum() > 0:
            df_processed[col].fillna(df_processed[col].mode()[0], inplace=True)
            print(f"  ✓ Filled {col} with mode")

missing_after = df_processed.isnull().sum().sum()
print(f"Missing values after: {missing_after}")
print("✓ Missing values handled!")

# 2. Convert Date and Time columns to datetime
print("\n" + "=" * 80)
print("2. DATETIME CONVERSION")
print("=" * 80)

if 'Date' in df_processed.columns:
    df_processed['Date'] = pd.to_datetime(df_processed['Date'], format='%m/%d/%Y', errors='coerce')
    print(f"✓ Date column converted to datetime")
    print(f"  Date range: {df_processed['Date'].min()} to {df_processed['Date'].max()}")
    
    # Extract useful datetime features
    df_processed['Year'] = df_processed['Date'].dt.year
    df_processed['Month'] = df_processed['Date'].dt.month
    df_processed['Day'] = df_processed['Date'].dt.day
    df_processed['DayOfWeek'] = df_processed['Date'].dt.dayofweek
    df_processed['WeekOfYear'] = df_processed['Date'].dt.isocalendar().week
    print("✓ Extracted date features: Year, Month, Day, DayOfWeek, WeekOfYear")

if 'Time' in df_processed.columns:
    # Convert time to hour (numerical)
    df_processed['Hour'] = pd.to_datetime(df_processed['Time'], format='%H:%M', errors='coerce').dt.hour
    print(f"✓ Time column converted - extracted Hour feature")

# 3. Encode categorical variables
print("\n" + "=" * 80)
print("3. ENCODING CATEGORICAL VARIABLES")
print("=" * 80)

# Identify categorical columns (excluding Invoice ID and datetime columns)
exclude_cols = ['Invoice ID', 'Date', 'Time']
categorical_cols = df_processed.select_dtypes(include=['object']).columns.tolist()
categorical_cols = [col for col in categorical_cols if col not in exclude_cols]

print(f"Categorical columns to encode: {categorical_cols}")

# Label Encoding
label_encoders = {}
df_encoded = df_processed.copy()

for col in categorical_cols:
    le = LabelEncoder()
    df_encoded[f'{col}_Encoded'] = le.fit_transform(df_processed[col])
    label_encoders[col] = le
    print(f"  ✓ {col}: {len(le.classes_)} unique values → Encoded")
    print(f"    Classes: {le.classes_[:5]}..." if len(le.classes_) > 5 else f"    Classes: {le.classes_}")

# Save encoded dataset
df_encoded.to_csv('supermarket_sales_encoded.csv', index=False)
print(f"\n✓ Encoded dataset saved to 'supermarket_sales_encoded.csv'")

# 4. Feature Scaling/Normalization
print("\n" + "=" * 80)
print("4. FEATURE SCALING")
print("=" * 80)

# Select numerical features for scaling (excluding encoded features and IDs)
numerical_features = ['Unit price', 'Quantity', 'Tax 5%', 'Total', 'cogs', 
                      'gross margin percentage', 'gross income', 'Rating']
numerical_features = [col for col in numerical_features if col in df_encoded.columns]

# Add datetime features
if 'Year' in df_encoded.columns:
    numerical_features.extend(['Year', 'Month', 'Day', 'DayOfWeek', 'WeekOfYear', 'Hour'])

print(f"Features to scale: {numerical_features}")

# StandardScaler
scaler = StandardScaler()
df_scaled = df_encoded.copy()
df_scaled[numerical_features] = scaler.fit_transform(df_encoded[numerical_features])

print("✓ Features scaled using StandardScaler (mean=0, std=1)")

# Save scaled dataset
df_scaled.to_csv('supermarket_sales_scaled.csv', index=False)
print(f"✓ Scaled dataset saved to 'supermarket_sales_scaled.csv'")

# 5. Summary
print("\n" + "=" * 80)
print("PREPROCESSING SUMMARY")
print("=" * 80)
print(f"Original shape: {df.shape}")
print(f"Processed shape: {df_encoded.shape}")
print(f"New features created: {df_encoded.shape[1] - df.shape[1]}")
print(f"Missing values: {df_encoded.isnull().sum().sum()}")

# Save preprocessing report
with open('preprocessing_report.txt', 'w') as f:
    f.write("=" * 80 + "\n")
    f.write("DATA CLEANING & PREPROCESSING REPORT\n")
    f.write("=" * 80 + "\n\n")
    
    f.write(f"1. Missing Values Handling:\n")
    f.write(f"   - Before: {missing_before}\n")
    f.write(f"   - After: {missing_after}\n\n")
    
    f.write(f"2. Datetime Conversion:\n")
    f.write(f"   - Date range: {df_processed['Date'].min()} to {df_processed['Date'].max()}\n")
    f.write(f"   - Features extracted: Year, Month, Day, DayOfWeek, WeekOfYear, Hour\n\n")
    
    f.write(f"3. Categorical Encoding:\n")
    for col in categorical_cols:
        f.write(f"   - {col}: {len(label_encoders[col].classes_)} classes\n")
    
    f.write(f"\n4. Feature Scaling:\n")
    f.write(f"   - Method: StandardScaler\n")
    f.write(f"   - Features scaled: {len(numerical_features)}\n\n")
    
    f.write(f"Final Dataset Shape: {df_encoded.shape}\n")

print("✓ Preprocessing report saved to 'preprocessing_report.txt'")

# Save label encoders for later use
import pickle
with open('label_encoders.pkl', 'wb') as f:
    pickle.dump(label_encoders, f)
print("✓ Label encoders saved to 'label_encoders.pkl'")

with open('scaler.pkl', 'wb') as f:
    pickle.dump(scaler, f)
print("✓ Scaler saved to 'scaler.pkl'")

print("\n✅ Step 2 completed successfully!")
