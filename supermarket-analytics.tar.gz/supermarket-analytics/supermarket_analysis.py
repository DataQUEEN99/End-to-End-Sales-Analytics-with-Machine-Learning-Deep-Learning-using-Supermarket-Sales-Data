#!/usr/bin/env python3
"""
Complete Supermarket Sales Data Analytics Pipeline
Integrated script with all analysis steps
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.linear_model import LinearRegression, Ridge, Lasso
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import xgboost as xgb
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers, callbacks
import warnings
warnings.filterwarnings('ignore')

print("=" * 80)
print("SUPERMARKET SALES DATA ANALYTICS - COMPLETE PIPELINE")
print("=" * 80)
print(f"TensorFlow: {tf.__version__} | Pandas: {pd.__version__} | NumPy: {np.__version__}")
print("=" * 80)

# =============================================================================
# STEP 1: DATA LOADING
# =============================================================================
print("\n📂 STEP 1: Loading Dataset...")
df = pd.read_csv('supermarket_sales.csv')
print(f"✓ Dataset loaded: {df.shape[0]} rows × {df.shape[1]} columns")
print(f"✓ Date range: {df['Date'].min()} to {df['Date'].max()}")

# =============================================================================
# STEP 2: DATA PREPROCESSING
# =============================================================================
print("\n🔧 STEP 2: Data Preprocessing...")

# Convert datetime
df['Date'] = pd.to_datetime(df['Date'], format='%m/%d/%Y')
df['Hour'] = pd.to_datetime(df['Time'], format='%H:%M').dt.hour
df['Month'] = df['Date'].dt.month
df['DayOfWeek'] = df['Date'].dt.dayofweek

# Encode categorical variables
categorical_cols = ['Branch', 'City', 'Customer type', 'Gender', 'Product line', 'Payment']
df_encoded = df.copy()

for col in categorical_cols:
    le = LabelEncoder()
    df_encoded[f'{col}_Encoded'] = le.fit_transform(df[col])

print(f"✓ Features engineered: {df_encoded.shape[1] - df.shape[1]} new columns")

# =============================================================================
# STEP 3: EXPLORATORY DATA ANALYSIS
# =============================================================================
print("\n📊 STEP 3: Exploratory Data Analysis...")

print("\nBusiness Metrics:")
print(f"  Total Revenue: ${df['Total'].sum():,.2f}")
print(f"  Average Transaction: ${df['Total'].mean():.2f}")
print(f"  Total Items Sold: {df['Quantity'].sum():,}")
print(f"  Average Rating: {df['Rating'].mean():.2f}/10")

print("\nTop Performers:")
print(f"  Best Branch: {df.groupby('Branch')['Total'].sum().idxmax()}")
print(f"  Best Product: {df.groupby('Product line')['Total'].sum().idxmax()}")

# =============================================================================
# STEP 4: MODEL TRAINING - MACHINE LEARNING
# =============================================================================
print("\n🤖 STEP 4: Training Machine Learning Models...")

# Prepare features
feature_cols = ['Unit price', 'Quantity', 'Rating', 'Month', 'DayOfWeek', 'Hour',
                'Branch_Encoded', 'Customer type_Encoded', 'Gender_Encoded', 
                'Product line_Encoded', 'Payment_Encoded']

X = df_encoded[feature_cols]
y = df_encoded['Total']

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Scale features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Train models
ml_models = {
    'Linear Regression': LinearRegression(),
    'Ridge': Ridge(alpha=1.0),
    'Lasso': Lasso(alpha=0.1),
    'Random Forest': RandomForestRegressor(n_estimators=100, random_state=42),
    'Gradient Boosting': GradientBoostingRegressor(n_estimators=100, random_state=42),
    'XGBoost': xgb.XGBRegressor(n_estimators=100, random_state=42)
}

ml_results = {}
for name, model in ml_models.items():
    model.fit(X_train_scaled, y_train)
    y_pred = model.predict(X_test_scaled)
    
    mae = mean_absolute_error(y_test, y_pred)
    rmse = np.sqrt(mean_squared_error(y_test, y_pred))
    r2 = r2_score(y_test, y_pred)
    
    ml_results[name] = {'MAE': mae, 'RMSE': rmse, 'R2': r2}
    print(f"  ✓ {name:20s} - R²: {r2:.4f}, RMSE: {rmse:.2f}")

# =============================================================================
# STEP 5: MODEL TRAINING - DEEP LEARNING
# =============================================================================
print("\n🧠 STEP 5: Training Deep Learning Model...")

# Further split for validation
X_train_dl, X_val, y_train_dl, y_val = train_test_split(
    X_train_scaled, y_train, test_size=0.2, random_state=42
)

# Build neural network
model_dl = keras.Sequential([
    layers.Input(shape=(X_train_scaled.shape[1],)),
    layers.Dense(128, activation='relu'),
    layers.BatchNormalization(),
    layers.Dropout(0.3),
    layers.Dense(64, activation='relu'),
    layers.BatchNormalization(),
    layers.Dropout(0.3),
    layers.Dense(32, activation='relu'),
    layers.BatchNormalization(),
    layers.Dropout(0.15),
    layers.Dense(1)
])

model_dl.compile(optimizer='adam', loss='mse', metrics=['mae'])

# Train with early stopping
early_stop = callbacks.EarlyStopping(monitor='val_loss', patience=20, restore_best_weights=True)

history = model_dl.fit(
    X_train_dl, y_train_dl,
    validation_data=(X_val, y_val),
    epochs=200,
    batch_size=32,
    callbacks=[early_stop],
    verbose=0
)

# Evaluate deep learning model
y_pred_dl = model_dl.predict(X_test_scaled, verbose=0).flatten()
mae_dl = mean_absolute_error(y_test, y_pred_dl)
rmse_dl = np.sqrt(mean_squared_error(y_test, y_pred_dl))
r2_dl = r2_score(y_test, y_pred_dl)

print(f"  ✓ Deep Learning Model - R²: {r2_dl:.4f}, RMSE: {rmse_dl:.2f}")

# =============================================================================
# STEP 6: MODEL COMPARISON
# =============================================================================
print("\n📈 STEP 6: Model Comparison...")

# Add DL to results
ml_results['Deep Learning'] = {'MAE': mae_dl, 'RMSE': rmse_dl, 'R2': r2_dl}

# Create comparison dataframe
results_df = pd.DataFrame(ml_results).T.sort_values('R2', ascending=False)

print("\nModel Performance Rankings:")
print(results_df.to_string())

best_model = results_df.index[0]
print(f"\n🏆 BEST MODEL: {best_model}")
print(f"   R² Score: {results_df.loc[best_model, 'R2']:.4f}")
print(f"   RMSE: {results_df.loc[best_model, 'RMSE']:.2f}")
print(f"   MAE: {results_df.loc[best_model, 'MAE']:.2f}")

# =============================================================================
# STEP 7: KEY INSIGHTS
# =============================================================================
print("\n💡 STEP 7: Key Business Insights...")

print("\nSales by Branch:")
branch_stats = df.groupby('Branch')['Total'].agg(['sum', 'mean', 'count'])
print(branch_stats.to_string())

print("\nTop 5 Product Lines:")
product_stats = df.groupby('Product line')['Total'].sum().sort_values(ascending=False).head()
print(product_stats.to_string())

print("\nCustomer Type Contribution:")
customer_stats = df.groupby('Customer type')['Total'].sum()
print(customer_stats.to_string())

# =============================================================================
# STEP 8: RECOMMENDATIONS
# =============================================================================
print("\n🎯 STEP 8: Recommendations...")

recommendations = [
    "1. Deploy Gradient Boosting model for sales forecasting",
    "2. Focus inventory on top 3 product lines",
    "3. Investigate underperforming branches",
    "4. Promote e-wallet payment adoption",
    "5. Optimize pricing based on model insights"
]

for rec in recommendations:
    print(f"  ✓ {rec}")

# =============================================================================
# SUMMARY
# =============================================================================
print("\n" + "=" * 80)
print("ANALYSIS COMPLETE!")
print("=" * 80)
print(f"✓ Dataset: {df.shape[0]:,} transactions analyzed")
print(f"✓ Models: {len(ml_results)} models trained")
print(f"✓ Best R²: {results_df['R2'].max():.4f} ({results_df['R2'].idxmax()})")
print(f"✓ Revenue: ${df['Total'].sum():,.2f}")
print("=" * 80)
print("\n✅ All analysis steps completed successfully!")
print("📁 Check individual step scripts for detailed outputs and visualizations")
print("=" * 80)
