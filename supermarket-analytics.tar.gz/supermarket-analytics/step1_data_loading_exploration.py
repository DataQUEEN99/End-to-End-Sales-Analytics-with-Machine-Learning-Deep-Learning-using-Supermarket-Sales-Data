#!/usr/bin/env python3
"""
Step 1: Data Loading & Exploration
Load the dataset and perform initial exploration
"""
import pandas as pd
import numpy as np
import warnings
warnings.filterwarnings('ignore')

print("=" * 80)
print("STEP 1: DATA LOADING & EXPLORATION")
print("=" * 80)

# Load the dataset
print("\n📂 Loading dataset...")
df = pd.read_csv('supermarket_sales.csv')
print("✓ Dataset loaded successfully!")

# Display first 10 rows
print("\n" + "=" * 80)
print("FIRST 10 ROWS OF THE DATASET")
print("=" * 80)
print(df.head(10).to_string())

# Dataset shape
print("\n" + "=" * 80)
print("DATASET SHAPE")
print("=" * 80)
print(f"Number of rows: {df.shape[0]}")
print(f"Number of columns: {df.shape[1]}")

# Dataset info
print("\n" + "=" * 80)
print("DATASET INFO")
print("=" * 80)
df.info()

# Check for missing values
print("\n" + "=" * 80)
print("MISSING VALUES")
print("=" * 80)
missing_values = df.isnull().sum()
if missing_values.sum() == 0:
    print("✓ No missing values found in the dataset!")
else:
    print(missing_values[missing_values > 0])

# Data types
print("\n" + "=" * 80)
print("DATA TYPES")
print("=" * 80)
print(df.dtypes)

# Descriptive statistics for numerical columns
print("\n" + "=" * 80)
print("DESCRIPTIVE STATISTICS (NUMERICAL COLUMNS)")
print("=" * 80)
print(df.describe().to_string())

# Identify categorical vs numerical features
print("\n" + "=" * 80)
print("FEATURE TYPES")
print("=" * 80)

numerical_features = df.select_dtypes(include=['int64', 'float64']).columns.tolist()
categorical_features = df.select_dtypes(include=['object']).columns.tolist()

print(f"\n📊 Numerical Features ({len(numerical_features)}):")
for i, feat in enumerate(numerical_features, 1):
    print(f"  {i}. {feat}")

print(f"\n📋 Categorical Features ({len(categorical_features)}):")
for i, feat in enumerate(categorical_features, 1):
    print(f"  {i}. {feat}")

# Value counts for categorical features
print("\n" + "=" * 80)
print("CATEGORICAL FEATURES - UNIQUE VALUE COUNTS")
print("=" * 80)
for col in categorical_features:
    print(f"\n{col}:")
    print(df[col].value_counts())
    print(f"Number of unique values: {df[col].nunique()}")

# Save summary to file
print("\n" + "=" * 80)
print("SAVING EXPLORATION RESULTS")
print("=" * 80)

with open('exploration_report.txt', 'w') as f:
    f.write("=" * 80 + "\n")
    f.write("DATA LOADING & EXPLORATION REPORT\n")
    f.write("=" * 80 + "\n\n")
    
    f.write(f"Dataset Shape: {df.shape[0]} rows × {df.shape[1]} columns\n\n")
    
    f.write("Numerical Features:\n")
    for feat in numerical_features:
        f.write(f"  - {feat}\n")
    
    f.write(f"\nCategorical Features:\n")
    for feat in categorical_features:
        f.write(f"  - {feat}\n")
    
    f.write(f"\n\nDescriptive Statistics:\n")
    f.write(df.describe().to_string())
    
    f.write(f"\n\nMissing Values:\n")
    f.write(f"Total missing values: {df.isnull().sum().sum()}\n")

print("✓ Exploration report saved to 'exploration_report.txt'")
print("\n✅ Step 1 completed successfully!")
