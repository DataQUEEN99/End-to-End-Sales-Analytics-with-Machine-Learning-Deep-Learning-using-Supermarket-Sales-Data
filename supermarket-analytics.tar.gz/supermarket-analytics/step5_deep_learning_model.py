#!/usr/bin/env python3
"""
Step 5: Deep Learning Model Training
Build and train a Neural Network for sales prediction
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers, callbacks
import warnings
warnings.filterwarnings('ignore')

# Set random seeds for reproducibility
np.random.seed(42)
tf.random.set_seed(42)

print("=" * 80)
print("STEP 5: DEEP LEARNING MODEL TRAINING")
print("=" * 80)
print(f"TensorFlow version: {tf.__version__}")
print(f"GPU available: {tf.config.list_physical_devices('GPU')}")

# Load encoded dataset
print("\n📂 Loading preprocessed dataset...")
df = pd.read_csv('supermarket_sales_encoded.csv')
print(f"✓ Dataset loaded: {df.shape}")

# Prepare features and target
print("\n" + "=" * 80)
print("1. DATA PREPARATION")
print("=" * 80)

target = 'Total'

feature_cols = [
    'Unit price', 'Quantity', 'Rating',
    'Branch_Encoded', 'City_Encoded', 'Customer type_Encoded',
    'Gender_Encoded', 'Product line_Encoded', 'Payment_Encoded'
]

# Add datetime features if they exist
datetime_features = ['Year', 'Month', 'Day', 'DayOfWeek', 'WeekOfYear', 'Hour']
for feat in datetime_features:
    if feat in df.columns:
        feature_cols.append(feat)

# Remove target-related features
leakage_cols = ['Tax 5%', 'cogs', 'gross income', 'gross margin percentage']
feature_cols = [col for col in feature_cols if col in df.columns and col not in leakage_cols]

print(f"Target variable: {target}")
print(f"Number of features: {len(feature_cols)}")

X = df[feature_cols].copy()
y = df[target].copy()

if X.isnull().sum().sum() > 0:
    X.fillna(X.median(), inplace=True)

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Further split training set for validation
X_train, X_val, y_train, y_val = train_test_split(X_train, y_train, test_size=0.2, random_state=42)

print(f"\nTraining set: {X_train.shape[0]} samples")
print(f"Validation set: {X_val.shape[0]} samples")
print(f"Test set: {X_test.shape[0]} samples")

# Feature Scaling
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_val_scaled = scaler.transform(X_val)
X_test_scaled = scaler.transform(X_test)
print("✓ Features scaled")

# 2. Build Neural Network Architecture
print("\n" + "=" * 80)
print("2. BUILDING NEURAL NETWORK")
print("=" * 80)

def create_model(input_dim, neurons_l1=128, neurons_l2=64, neurons_l3=32, 
                 dropout_rate=0.3, learning_rate=0.001):
    """
    Create a feedforward neural network for regression
    """
    model = keras.Sequential([
        # Input layer
        layers.Input(shape=(input_dim,)),
        
        # Hidden Layer 1
        layers.Dense(neurons_l1, activation='relu', kernel_initializer='he_normal'),
        layers.BatchNormalization(),
        layers.Dropout(dropout_rate),
        
        # Hidden Layer 2
        layers.Dense(neurons_l2, activation='relu', kernel_initializer='he_normal'),
        layers.BatchNormalization(),
        layers.Dropout(dropout_rate),
        
        # Hidden Layer 3
        layers.Dense(neurons_l3, activation='relu', kernel_initializer='he_normal'),
        layers.BatchNormalization(),
        layers.Dropout(dropout_rate / 2),
        
        # Output layer for regression
        layers.Dense(1, activation='linear')
    ])
    
    # Compile model
    optimizer = keras.optimizers.Adam(learning_rate=learning_rate)
    model.compile(
        optimizer=optimizer,
        loss='mse',
        metrics=['mae', 'mse']
    )
    
    return model

# Create the model
input_dim = X_train_scaled.shape[1]
model = create_model(input_dim)

print("Model Architecture:")
model.summary()

# 3. Training
print("\n" + "=" * 80)
print("3. TRAINING NEURAL NETWORK")
print("=" * 80)

# Callbacks
early_stopping = callbacks.EarlyStopping(
    monitor='val_loss',
    patience=20,
    restore_best_weights=True,
    verbose=1
)

reduce_lr = callbacks.ReduceLROnPlateau(
    monitor='val_loss',
    factor=0.5,
    patience=10,
    min_lr=1e-7,
    verbose=1
)

# Train the model
history = model.fit(
    X_train_scaled, y_train,
    validation_data=(X_val_scaled, y_val),
    epochs=200,
    batch_size=32,
    callbacks=[early_stopping, reduce_lr],
    verbose=1
)

print("\n✓ Model training completed!")

# 4. Evaluation
print("\n" + "=" * 80)
print("4. MODEL EVALUATION")
print("=" * 80)

# Predictions
y_train_pred = model.predict(X_train_scaled, verbose=0).flatten()
y_val_pred = model.predict(X_val_scaled, verbose=0).flatten()
y_test_pred = model.predict(X_test_scaled, verbose=0).flatten()

# Calculate metrics
def calculate_metrics(y_true, y_pred, set_name):
    mae = mean_absolute_error(y_true, y_pred)
    mse = mean_squared_error(y_true, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_true, y_pred)
    
    print(f"\n{set_name} Metrics:")
    print(f"  MAE:  {mae:.4f}")
    print(f"  MSE:  {mse:.4f}")
    print(f"  RMSE: {rmse:.4f}")
    print(f"  R²:   {r2:.4f}")
    
    return {'mae': mae, 'mse': mse, 'rmse': rmse, 'r2': r2}

train_metrics = calculate_metrics(y_train, y_train_pred, "Training Set")
val_metrics = calculate_metrics(y_val, y_val_pred, "Validation Set")
test_metrics = calculate_metrics(y_test, y_test_pred, "Test Set")

# 5. Visualizations
print("\n" + "=" * 80)
print("5. GENERATING VISUALIZATIONS")
print("=" * 80)

import os
os.makedirs('plots', exist_ok=True)

# Plot 1: Training History - Loss Curves
fig, axes = plt.subplots(1, 2, figsize=(16, 5))

# Loss curve
axes[0].plot(history.history['loss'], label='Training Loss', linewidth=2)
axes[0].plot(history.history['val_loss'], label='Validation Loss', linewidth=2)
axes[0].set_title('Model Loss Over Epochs', fontsize=14, fontweight='bold')
axes[0].set_xlabel('Epoch')
axes[0].set_ylabel('Loss (MSE)')
axes[0].legend()
axes[0].grid(True, alpha=0.3)

# MAE curve
axes[1].plot(history.history['mae'], label='Training MAE', linewidth=2)
axes[1].plot(history.history['val_mae'], label='Validation MAE', linewidth=2)
axes[1].set_title('Model MAE Over Epochs', fontsize=14, fontweight='bold')
axes[1].set_xlabel('Epoch')
axes[1].set_ylabel('MAE')
axes[1].legend()
axes[1].grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig('plots/15_dl_training_history.png', dpi=300, bbox_inches='tight')
print("✓ Saved: plots/15_dl_training_history.png")
plt.close()

# Plot 2: Predicted vs Actual
fig, axes = plt.subplots(1, 3, figsize=(18, 5))

# Training set
axes[0].scatter(y_train, y_train_pred, alpha=0.6, s=20)
axes[0].plot([y_train.min(), y_train.max()], [y_train.min(), y_train.max()], 
             'r--', lw=2, label='Perfect Prediction')
axes[0].set_title(f'Training Set\nR²={train_metrics["r2"]:.4f}', fontsize=12, fontweight='bold')
axes[0].set_xlabel('Actual Total Sales')
axes[0].set_ylabel('Predicted Total Sales')
axes[0].legend()
axes[0].grid(True, alpha=0.3)

# Validation set
axes[1].scatter(y_val, y_val_pred, alpha=0.6, s=20, color='orange')
axes[1].plot([y_val.min(), y_val.max()], [y_val.min(), y_val.max()], 
             'r--', lw=2, label='Perfect Prediction')
axes[1].set_title(f'Validation Set\nR²={val_metrics["r2"]:.4f}', fontsize=12, fontweight='bold')
axes[1].set_xlabel('Actual Total Sales')
axes[1].set_ylabel('Predicted Total Sales')
axes[1].legend()
axes[1].grid(True, alpha=0.3)

# Test set
axes[2].scatter(y_test, y_test_pred, alpha=0.6, s=20, color='green')
axes[2].plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 
             'r--', lw=2, label='Perfect Prediction')
axes[2].set_title(f'Test Set\nR²={test_metrics["r2"]:.4f}', fontsize=12, fontweight='bold')
axes[2].set_xlabel('Actual Total Sales')
axes[2].set_ylabel('Predicted Total Sales')
axes[2].legend()
axes[2].grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig('plots/16_dl_predicted_vs_actual.png', dpi=300, bbox_inches='tight')
print("✓ Saved: plots/16_dl_predicted_vs_actual.png")
plt.close()

# Plot 3: Residual Analysis
residuals = y_test.values - y_test_pred

fig, axes = plt.subplots(1, 2, figsize=(14, 5))

# Residual plot
axes[0].scatter(y_test_pred, residuals, alpha=0.6)
axes[0].axhline(y=0, color='r', linestyle='--', lw=2)
axes[0].set_title('Residual Plot - Deep Learning Model', fontsize=14, fontweight='bold')
axes[0].set_xlabel('Predicted Values')
axes[0].set_ylabel('Residuals')
axes[0].grid(True, alpha=0.3)

# Residual distribution
axes[1].hist(residuals, bins=30, edgecolor='black', alpha=0.7)
axes[1].axvline(x=0, color='r', linestyle='--', lw=2)
axes[1].set_title('Residual Distribution', fontsize=14, fontweight='bold')
axes[1].set_xlabel('Residuals')
axes[1].set_ylabel('Frequency')
axes[1].grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig('plots/17_dl_residual_analysis.png', dpi=300, bbox_inches='tight')
print("✓ Saved: plots/17_dl_residual_analysis.png")
plt.close()

# Plot 4: Error Distribution
errors = np.abs(y_test.values - y_test_pred)

plt.figure(figsize=(10, 6))
plt.hist(errors, bins=30, edgecolor='black', alpha=0.7, color='skyblue')
plt.axvline(errors.mean(), color='red', linestyle='--', linewidth=2, 
            label=f'Mean Error: {errors.mean():.2f}')
plt.axvline(np.median(errors), color='green', linestyle='--', linewidth=2, 
            label=f'Median Error: {np.median(errors):.2f}')
plt.title('Absolute Error Distribution', fontsize=16, fontweight='bold')
plt.xlabel('Absolute Error')
plt.ylabel('Frequency')
plt.legend()
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig('plots/18_dl_error_distribution.png', dpi=300, bbox_inches='tight')
print("✓ Saved: plots/18_dl_error_distribution.png")
plt.close()

# 6. Save Model and Results
print("\n" + "=" * 80)
print("6. SAVING MODEL AND RESULTS")
print("=" * 80)

# Save the model
model.save('dl_model.h5')
print("✓ Model saved to 'dl_model.h5'")

# Save scaler
import pickle
with open('dl_scaler.pkl', 'wb') as f:
    pickle.dump(scaler, f)
print("✓ Scaler saved to 'dl_scaler.pkl'")

# Save predictions
predictions_df = pd.DataFrame({
    'Actual': y_test.values,
    'Predicted': y_test_pred,
    'Error': y_test.values - y_test_pred,
    'Absolute_Error': errors
})
predictions_df.to_csv('dl_predictions.csv', index=False)
print("✓ Predictions saved to 'dl_predictions.csv'")

# Save metrics
metrics_df = pd.DataFrame({
    'Train': train_metrics,
    'Validation': val_metrics,
    'Test': test_metrics
})
metrics_df.to_csv('dl_metrics.csv')
print("✓ Metrics saved to 'dl_metrics.csv'")

# Save report
with open('dl_report.txt', 'w') as f:
    f.write("=" * 80 + "\n")
    f.write("DEEP LEARNING MODEL REPORT\n")
    f.write("=" * 80 + "\n\n")
    
    f.write("Model Architecture:\n")
    f.write(f"  Input Features: {input_dim}\n")
    f.write(f"  Hidden Layer 1: 128 neurons (ReLU)\n")
    f.write(f"  Hidden Layer 2: 64 neurons (ReLU)\n")
    f.write(f"  Hidden Layer 3: 32 neurons (ReLU)\n")
    f.write(f"  Output Layer: 1 neuron (Linear)\n")
    f.write(f"  Dropout Rate: 0.3\n")
    f.write(f"  Optimizer: Adam\n")
    f.write(f"  Loss Function: MSE\n\n")
    
    f.write("Training Configuration:\n")
    f.write(f"  Epochs: {len(history.history['loss'])}\n")
    f.write(f"  Batch Size: 32\n")
    f.write(f"  Early Stopping: Yes (patience=20)\n\n")
    
    f.write("Performance Metrics:\n\n")
    f.write(metrics_df.to_string())
    
    f.write("\n\n" + "=" * 80 + "\n")
    f.write("KEY FINDINGS:\n")
    f.write("=" * 80 + "\n")
    f.write(f"✓ Test R² Score: {test_metrics['r2']:.4f}\n")
    f.write(f"✓ Test RMSE: {test_metrics['rmse']:.4f}\n")
    f.write(f"✓ Test MAE: {test_metrics['mae']:.4f}\n")
    f.write(f"✓ Mean Absolute Error: ${errors.mean():.2f}\n")
    f.write(f"✓ Median Absolute Error: ${np.median(errors):.2f}\n")

print("✓ DL report saved to 'dl_report.txt'")
print("\n✅ Step 5 completed successfully!")
