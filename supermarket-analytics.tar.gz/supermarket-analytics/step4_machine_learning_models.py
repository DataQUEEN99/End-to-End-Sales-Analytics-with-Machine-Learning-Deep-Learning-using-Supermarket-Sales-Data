#!/usr/bin/env python3
"""
Step 4: Machine Learning Model Training
Train multiple ML models to predict Total sales
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression, Ridge, Lasso
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import xgboost as xgb
import warnings
warnings.filterwarnings('ignore')

print("=" * 80)
print("STEP 4: MACHINE LEARNING MODEL TRAINING")
print("=" * 80)

# Load encoded dataset
print("\n📂 Loading preprocessed dataset...")
df = pd.read_csv('supermarket_sales_encoded.csv')
print(f"✓ Dataset loaded: {df.shape}")

# Prepare features and target
print("\n" + "=" * 80)
print("1. FEATURE SELECTION & DATA PREPARATION")
print("=" * 80)

# Target variable
target = 'Total'

# Select features for modeling
feature_cols = [
    'Unit price', 'Quantity', 'Rating',
    'Branch_Encoded', 'City_Encoded', 'Customer type_Encoded',
    'Gender_Encoded', 'Product line_Encoded', 'Payment_Encoded'
]

# Add datetime features if they exist
datetime_features = ['Year', 'Month', 'Day', 'DayOfWeek', 'WeekOfYear', 'Hour']
for feat in datetime_features:
    if feat in df.columns:
        feature_cols.append(feat)

# Remove target-related features to avoid data leakage
leakage_cols = ['Tax 5%', 'cogs', 'gross income', 'gross margin percentage']
feature_cols = [col for col in feature_cols if col in df.columns and col not in leakage_cols]

print(f"Target variable: {target}")
print(f"Number of features: {len(feature_cols)}")
print(f"Features: {feature_cols}")

# Prepare X and y
X = df[feature_cols].copy()
y = df[target].copy()

print(f"\nX shape: {X.shape}")
print(f"y shape: {y.shape}")

# Check for any remaining missing values
if X.isnull().sum().sum() > 0:
    print("⚠ Warning: Missing values detected, filling with median...")
    X.fillna(X.median(), inplace=True)

# 2. Train-Test Split
print("\n" + "=" * 80)
print("2. TRAIN-TEST SPLIT")
print("=" * 80)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

print(f"Training set size: {X_train.shape[0]} samples ({X_train.shape[0]/len(X)*100:.1f}%)")
print(f"Test set size: {X_test.shape[0]} samples ({X_test.shape[0]/len(X)*100:.1f}%)")

# 3. Feature Scaling
print("\n" + "=" * 80)
print("3. FEATURE SCALING")
print("=" * 80)

scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)
print("✓ Features scaled using StandardScaler")

# 4. Model Training
print("\n" + "=" * 80)
print("4. TRAINING MACHINE LEARNING MODELS")
print("=" * 80)

models = {
    'Linear Regression': LinearRegression(),
    'Ridge Regression': Ridge(alpha=1.0, random_state=42),
    'Lasso Regression': Lasso(alpha=0.1, random_state=42),
    'Random Forest': RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1),
    'Gradient Boosting': GradientBoostingRegressor(n_estimators=100, random_state=42),
    'XGBoost': xgb.XGBRegressor(n_estimators=100, random_state=42, n_jobs=-1)
}

results = {}
predictions = {}

for name, model in models.items():
    print(f"\n{'='*60}")
    print(f"Training: {name}")
    print(f"{'='*60}")
    
    # Train the model
    model.fit(X_train_scaled, y_train)
    print("✓ Model trained")
    
    # Predictions
    y_train_pred = model.predict(X_train_scaled)
    y_test_pred = model.predict(X_test_scaled)
    predictions[name] = y_test_pred
    
    # Evaluation metrics
    train_mae = mean_absolute_error(y_train, y_train_pred)
    test_mae = mean_absolute_error(y_test, y_test_pred)
    
    train_mse = mean_squared_error(y_train, y_train_pred)
    test_mse = mean_squared_error(y_test, y_test_pred)
    
    train_rmse = np.sqrt(train_mse)
    test_rmse = np.sqrt(test_mse)
    
    train_r2 = r2_score(y_train, y_train_pred)
    test_r2 = r2_score(y_test, y_test_pred)
    
    results[name] = {
        'train_mae': train_mae,
        'test_mae': test_mae,
        'train_mse': train_mse,
        'test_mse': test_mse,
        'train_rmse': train_rmse,
        'test_rmse': test_rmse,
        'train_r2': train_r2,
        'test_r2': test_r2
    }
    
    print(f"\nTraining Metrics:")
    print(f"  MAE:  {train_mae:.4f}")
    print(f"  MSE:  {train_mse:.4f}")
    print(f"  RMSE: {train_rmse:.4f}")
    print(f"  R²:   {train_r2:.4f}")
    
    print(f"\nTest Metrics:")
    print(f"  MAE:  {test_mae:.4f}")
    print(f"  MSE:  {test_mse:.4f}")
    print(f"  RMSE: {test_rmse:.4f}")
    print(f"  R²:   {test_r2:.4f}")

# 5. Model Comparison
print("\n" + "=" * 80)
print("5. MODEL COMPARISON")
print("=" * 80)

results_df = pd.DataFrame(results).T
print("\nTest Set Performance:")
print(results_df[['test_mae', 'test_rmse', 'test_r2']].sort_values('test_r2', ascending=False))

best_model_name = results_df['test_r2'].idxmax()
print(f"\n🏆 Best Model: {best_model_name}")
print(f"   Test R² Score: {results_df.loc[best_model_name, 'test_r2']:.4f}")
print(f"   Test RMSE: {results_df.loc[best_model_name, 'test_rmse']:.4f}")

# 6. Visualizations
print("\n" + "=" * 80)
print("6. GENERATING VISUALIZATIONS")
print("=" * 80)

import os
os.makedirs('plots', exist_ok=True)

# Plot 1: Model Performance Comparison
fig, axes = plt.subplots(2, 2, figsize=(16, 12))

# R² Score comparison
axes[0, 0].bar(results_df.index, results_df['test_r2'], color=plt.cm.viridis(np.linspace(0, 1, len(results_df))))
axes[0, 0].set_title('R² Score Comparison (Test Set)', fontsize=14, fontweight='bold')
axes[0, 0].set_ylabel('R² Score')
axes[0, 0].tick_params(axis='x', rotation=45)
axes[0, 0].grid(True, alpha=0.3, axis='y')

# MAE comparison
axes[0, 1].bar(results_df.index, results_df['test_mae'], color=plt.cm.plasma(np.linspace(0, 1, len(results_df))))
axes[0, 1].set_title('Mean Absolute Error (Test Set)', fontsize=14, fontweight='bold')
axes[0, 1].set_ylabel('MAE')
axes[0, 1].tick_params(axis='x', rotation=45)
axes[0, 1].grid(True, alpha=0.3, axis='y')

# RMSE comparison
axes[1, 0].bar(results_df.index, results_df['test_rmse'], color=plt.cm.coolwarm(np.linspace(0, 1, len(results_df))))
axes[1, 0].set_title('Root Mean Squared Error (Test Set)', fontsize=14, fontweight='bold')
axes[1, 0].set_ylabel('RMSE')
axes[1, 0].tick_params(axis='x', rotation=45)
axes[1, 0].grid(True, alpha=0.3, axis='y')

# Train vs Test R² comparison
x_pos = np.arange(len(results_df))
width = 0.35
axes[1, 1].bar(x_pos - width/2, results_df['train_r2'], width, label='Train', color='steelblue')
axes[1, 1].bar(x_pos + width/2, results_df['test_r2'], width, label='Test', color='coral')
axes[1, 1].set_title('Train vs Test R² Score', fontsize=14, fontweight='bold')
axes[1, 1].set_ylabel('R² Score')
axes[1, 1].set_xticks(x_pos)
axes[1, 1].set_xticklabels(results_df.index, rotation=45, ha='right')
axes[1, 1].legend()
axes[1, 1].grid(True, alpha=0.3, axis='y')

plt.tight_layout()
plt.savefig('plots/11_ml_model_comparison.png', dpi=300, bbox_inches='tight')
print("✓ Saved: plots/11_ml_model_comparison.png")
plt.close()

# Plot 2: Predicted vs Actual for each model
fig, axes = plt.subplots(2, 3, figsize=(18, 12))
axes = axes.flatten()

for i, (name, y_pred) in enumerate(predictions.items()):
    axes[i].scatter(y_test, y_pred, alpha=0.6, s=20)
    axes[i].plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 
                 'r--', lw=2, label='Perfect Prediction')
    axes[i].set_title(f'{name}\nR²={results[name]["test_r2"]:.4f}', 
                      fontsize=12, fontweight='bold')
    axes[i].set_xlabel('Actual Total Sales')
    axes[i].set_ylabel('Predicted Total Sales')
    axes[i].legend()
    axes[i].grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig('plots/12_ml_predicted_vs_actual.png', dpi=300, bbox_inches='tight')
print("✓ Saved: plots/12_ml_predicted_vs_actual.png")
plt.close()

# Plot 3: Residual plots for best model
best_pred = predictions[best_model_name]
residuals = y_test - best_pred

fig, axes = plt.subplots(1, 2, figsize=(14, 5))

# Residual plot
axes[0].scatter(best_pred, residuals, alpha=0.6)
axes[0].axhline(y=0, color='r', linestyle='--', lw=2)
axes[0].set_title(f'Residual Plot - {best_model_name}', fontsize=14, fontweight='bold')
axes[0].set_xlabel('Predicted Values')
axes[0].set_ylabel('Residuals')
axes[0].grid(True, alpha=0.3)

# Residual distribution
axes[1].hist(residuals, bins=30, edgecolor='black', alpha=0.7)
axes[1].axvline(x=0, color='r', linestyle='--', lw=2)
axes[1].set_title(f'Residual Distribution - {best_model_name}', fontsize=14, fontweight='bold')
axes[1].set_xlabel('Residuals')
axes[1].set_ylabel('Frequency')
axes[1].grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig('plots/13_ml_residual_analysis.png', dpi=300, bbox_inches='tight')
print("✓ Saved: plots/13_ml_residual_analysis.png")
plt.close()

# Plot 4: Feature Importance (for tree-based models)
print("\n" + "=" * 80)
print("7. FEATURE IMPORTANCE ANALYSIS")
print("=" * 80)

tree_models = ['Random Forest', 'Gradient Boosting', 'XGBoost']
fig, axes = plt.subplots(1, 3, figsize=(20, 6))

for i, model_name in enumerate(tree_models):
    model = models[model_name]
    importances = model.feature_importances_
    indices = np.argsort(importances)[::-1]
    
    axes[i].barh(range(len(importances)), importances[indices], color=plt.cm.viridis(np.linspace(0, 1, len(importances))))
    axes[i].set_yticks(range(len(importances)))
    axes[i].set_yticklabels([feature_cols[idx] for idx in indices])
    axes[i].set_title(f'Feature Importance - {model_name}', fontsize=12, fontweight='bold')
    axes[i].set_xlabel('Importance')
    axes[i].grid(True, alpha=0.3, axis='x')
    
    print(f"\n{model_name} - Top 5 Features:")
    for idx in indices[:5]:
        print(f"  {feature_cols[idx]}: {importances[idx]:.4f}")

plt.tight_layout()
plt.savefig('plots/14_ml_feature_importance.png', dpi=300, bbox_inches='tight')
print("\n✓ Saved: plots/14_ml_feature_importance.png")
plt.close()

# Save results
print("\n" + "=" * 80)
print("SAVING RESULTS")
print("=" * 80)

results_df.to_csv('ml_model_results.csv')
print("✓ Model results saved to 'ml_model_results.csv'")

# Save models
import pickle
with open('ml_models.pkl', 'wb') as f:
    pickle.dump(models, f)
print("✓ Models saved to 'ml_models.pkl'")

with open('ml_scaler.pkl', 'wb') as f:
    pickle.dump(scaler, f)
print("✓ Scaler saved to 'ml_scaler.pkl'")

# Save report
with open('ml_report.txt', 'w') as f:
    f.write("=" * 80 + "\n")
    f.write("MACHINE LEARNING MODELS REPORT\n")
    f.write("=" * 80 + "\n\n")
    
    f.write(f"Dataset Shape: {X.shape}\n")
    f.write(f"Target Variable: {target}\n")
    f.write(f"Number of Features: {len(feature_cols)}\n\n")
    
    f.write("Features Used:\n")
    for feat in feature_cols:
        f.write(f"  - {feat}\n")
    
    f.write("\n\nModel Performance (Test Set):\n")
    f.write(results_df[['test_mae', 'test_rmse', 'test_r2']].to_string())
    
    f.write(f"\n\n{'='*80}\n")
    f.write(f"BEST MODEL: {best_model_name}\n")
    f.write(f"{'='*80}\n")
    f.write(f"Test MAE:  {results[best_model_name]['test_mae']:.4f}\n")
    f.write(f"Test RMSE: {results[best_model_name]['test_rmse']:.4f}\n")
    f.write(f"Test R²:   {results[best_model_name]['test_r2']:.4f}\n")

print("✓ ML report saved to 'ml_report.txt'")
print("\n✅ Step 4 completed successfully!")
