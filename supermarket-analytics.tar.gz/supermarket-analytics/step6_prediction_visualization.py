#!/usr/bin/env python3
"""
Step 6: Prediction & Visualization
Compare ML and DL models, feature importance, and insights
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import pickle
import warnings
warnings.filterwarnings('ignore')

print("=" * 80)
print("STEP 6: PREDICTION & VISUALIZATION - MODEL COMPARISON")
print("=" * 80)

# Load data
print("\n📂 Loading data and models...")
df = pd.read_csv('supermarket_sales.csv')
df_encoded = pd.read_csv('supermarket_sales_encoded.csv')

# Load ML results
ml_results = pd.read_csv('ml_model_results.csv', index_col=0)
print(f"✓ ML results loaded: {len(ml_results)} models")

# Load DL results
dl_metrics = pd.read_csv('dl_metrics.csv', index_col=0)
dl_predictions = pd.read_csv('dl_predictions.csv')
print(f"✓ DL results loaded")

# 1. Model Comparison
print("\n" + "=" * 80)
print("1. ML vs DL MODEL COMPARISON")
print("=" * 80)

# Create comparison dataframe
comparison = pd.DataFrame({
    'Model': list(ml_results.index) + ['Deep Learning'],
    'Test_MAE': list(ml_results['test_mae']) + [dl_metrics.loc['mae', 'Test']],
    'Test_RMSE': list(ml_results['test_rmse']) + [dl_metrics.loc['rmse', 'Test']],
    'Test_R2': list(ml_results['test_r2']) + [dl_metrics.loc['r2', 'Test']]
})

comparison = comparison.sort_values('Test_R2', ascending=False)
print("\nModel Performance Summary (sorted by R² score):")
print(comparison.to_string(index=False))

best_model = comparison.iloc[0]
print(f"\n🏆 OVERALL BEST MODEL: {best_model['Model']}")
print(f"   Test R²: {best_model['Test_R2']:.4f}")
print(f"   Test RMSE: {best_model['Test_RMSE']:.4f}")
print(f"   Test MAE: {best_model['Test_MAE']:.4f}")

# 2. Visualizations
print("\n" + "=" * 80)
print("2. GENERATING COMPARISON VISUALIZATIONS")
print("=" * 80)

import os
os.makedirs('plots', exist_ok=True)

# Plot 1: Comprehensive Model Comparison
fig, axes = plt.subplots(2, 2, figsize=(16, 12))

# R² Score comparison
colors = ['#FF6B6B' if model != best_model['Model'] else '#4CAF50' 
          for model in comparison['Model']]
axes[0, 0].barh(comparison['Model'], comparison['Test_R2'], color=colors)
axes[0, 0].set_title('R² Score Comparison (Higher is Better)', fontsize=14, fontweight='bold')
axes[0, 0].set_xlabel('R² Score')
axes[0, 0].grid(True, alpha=0.3, axis='x')
axes[0, 0].axvline(x=0.9, color='green', linestyle='--', alpha=0.5, label='Excellent (>0.9)')
axes[0, 0].legend()

# MAE comparison
axes[0, 1].barh(comparison['Model'], comparison['Test_MAE'], color=colors)
axes[0, 1].set_title('Mean Absolute Error (Lower is Better)', fontsize=14, fontweight='bold')
axes[0, 1].set_xlabel('MAE')
axes[0, 1].grid(True, alpha=0.3, axis='x')

# RMSE comparison
axes[1, 0].barh(comparison['Model'], comparison['Test_RMSE'], color=colors)
axes[1, 0].set_title('Root Mean Squared Error (Lower is Better)', fontsize=14, fontweight='bold')
axes[1, 0].set_xlabel('RMSE')
axes[1, 0].grid(True, alpha=0.3, axis='x')

# Model ranking
ranking = comparison.sort_values('Test_R2', ascending=True).reset_index(drop=True)
colors_rank = ['#4CAF50' if i == len(ranking)-1 else '#90CAF9' for i in range(len(ranking))]
axes[1, 1].barh(ranking['Model'], ranking['Test_R2'], color=colors_rank)
axes[1, 1].set_title('Model Ranking by R² Score', fontsize=14, fontweight='bold')
axes[1, 1].set_xlabel('R² Score')
axes[1, 1].grid(True, alpha=0.3, axis='x')

plt.tight_layout()
plt.savefig('plots/19_comprehensive_model_comparison.png', dpi=300, bbox_inches='tight')
print("✓ Saved: plots/19_comprehensive_model_comparison.png")
plt.close()

# Plot 2: Performance Metrics Spider Chart
from math import pi

categories = ['R² Score', 'MAE (Inverted)', 'RMSE (Inverted)']
fig = plt.figure(figsize=(14, 10))

# Normalize metrics for comparison (0-1 scale)
def normalize(values):
    min_val, max_val = min(values), max(values)
    return [(v - min_val) / (max_val - min_val) if max_val != min_val else 0 for v in values]

# Select top 5 models for spider chart
top_models = comparison.head(5)

for plot_idx, (idx, row) in enumerate(top_models.iterrows()):
    # Prepare values (invert MAE and RMSE so higher is better)
    r2_norm = row['Test_R2']
    mae_norm = 1 - normalize(comparison['Test_MAE'])[comparison['Model'].tolist().index(row['Model'])]
    rmse_norm = 1 - normalize(comparison['Test_RMSE'])[comparison['Model'].tolist().index(row['Model'])]
    
    values = [r2_norm, mae_norm, rmse_norm]
    values += values[:1]  # Complete the circle
    
    angles = [n / float(len(categories)) * 2 * pi for n in range(len(categories))]
    angles += angles[:1]
    
    ax = plt.subplot(2, 3, plot_idx + 1, projection='polar')
    ax.plot(angles, values, 'o-', linewidth=2, label=row['Model'])
    ax.fill(angles, values, alpha=0.25)
    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(categories)
    ax.set_ylim(0, 1)
    ax.set_title(row['Model'], fontsize=12, fontweight='bold', pad=20)
    ax.grid(True)

plt.tight_layout()
plt.savefig('plots/20_model_performance_radar.png', dpi=300, bbox_inches='tight')
print("✓ Saved: plots/20_model_performance_radar.png")
plt.close()

# 3. Sales Insights
print("\n" + "=" * 80)
print("3. BUSINESS INSIGHTS FROM DATA")
print("=" * 80)

insights = {}

# Total sales by Branch
if 'Branch' in df.columns and 'Total' in df.columns:
    branch_analysis = df.groupby('Branch').agg({
        'Total': ['sum', 'mean', 'count'],
        'Rating': 'mean',
        'Quantity': 'sum'
    }).round(2)
    insights['branch'] = branch_analysis
    print("\nSales by Branch:")
    print(branch_analysis)

# Total sales by Product Line
if 'Product line' in df.columns:
    product_analysis = df.groupby('Product line').agg({
        'Total': ['sum', 'mean', 'count'],
        'Rating': 'mean',
        'Quantity': 'sum'
    }).sort_values(('Total', 'sum'), ascending=False).round(2)
    insights['product'] = product_analysis
    print("\nSales by Product Line:")
    print(product_analysis)

# Customer Type Analysis
if 'Customer type' in df.columns:
    customer_analysis = df.groupby('Customer type').agg({
        'Total': ['sum', 'mean', 'count'],
        'Rating': 'mean'
    }).round(2)
    insights['customer'] = customer_analysis
    print("\nSales by Customer Type:")
    print(customer_analysis)

# Payment Method Analysis
if 'Payment' in df.columns:
    payment_analysis = df.groupby('Payment').agg({
        'Total': ['sum', 'mean', 'count']
    }).round(2)
    insights['payment'] = payment_analysis
    print("\nSales by Payment Method:")
    print(payment_analysis)

# Plot 3: Comprehensive Sales Insights
fig = plt.figure(figsize=(18, 12))

# Branch contribution
if 'branch' in insights:
    ax1 = plt.subplot(3, 3, 1)
    branch_total = insights['branch'][('Total', 'sum')]
    colors_branch = plt.cm.Set3(range(len(branch_total)))
    ax1.pie(branch_total, labels=branch_total.index, autopct='%1.1f%%', 
            colors=colors_branch, startangle=90)
    ax1.set_title('Revenue Contribution by Branch', fontsize=12, fontweight='bold')
    
    ax2 = plt.subplot(3, 3, 2)
    ax2.bar(insights['branch'].index, insights['branch'][('Total', 'mean')], 
            color=colors_branch)
    ax2.set_title('Average Transaction Value by Branch', fontsize=12, fontweight='bold')
    ax2.set_ylabel('Average Sales')
    ax2.grid(True, alpha=0.3, axis='y')
    
    ax3 = plt.subplot(3, 3, 3)
    ax3.bar(insights['branch'].index, insights['branch'][('Rating', 'mean')], 
            color=colors_branch)
    ax3.set_title('Average Rating by Branch', fontsize=12, fontweight='bold')
    ax3.set_ylabel('Rating')
    ax3.set_ylim([0, 10])
    ax3.grid(True, alpha=0.3, axis='y')

# Product Line contribution
if 'product' in insights:
    ax4 = plt.subplot(3, 3, 4)
    product_total = insights['product'][('Total', 'sum')].head(6)
    ax4.barh(product_total.index, product_total.values, 
             color=plt.cm.viridis(np.linspace(0, 1, len(product_total))))
    ax4.set_title('Top Product Lines by Revenue', fontsize=12, fontweight='bold')
    ax4.set_xlabel('Total Sales')
    ax4.grid(True, alpha=0.3, axis='x')
    
    ax5 = plt.subplot(3, 3, 5)
    product_count = insights['product'][('Total', 'count')].head(6)
    ax5.barh(product_count.index, product_count.values, 
             color=plt.cm.plasma(np.linspace(0, 1, len(product_count))))
    ax5.set_title('Top Product Lines by Transaction Count', fontsize=12, fontweight='bold')
    ax5.set_xlabel('Number of Transactions')
    ax5.grid(True, alpha=0.3, axis='x')
    
    ax6 = plt.subplot(3, 3, 6)
    product_rating = insights['product'][('Rating', 'mean')].head(6)
    ax6.barh(product_rating.index, product_rating.values, 
             color=plt.cm.coolwarm(np.linspace(0, 1, len(product_rating))))
    ax6.set_title('Product Lines by Rating', fontsize=12, fontweight='bold')
    ax6.set_xlabel('Average Rating')
    ax6.set_xlim([0, 10])
    ax6.grid(True, alpha=0.3, axis='x')

# Customer Type and Payment
if 'customer' in insights:
    ax7 = plt.subplot(3, 3, 7)
    customer_total = insights['customer'][('Total', 'sum')]
    ax7.bar(customer_total.index, customer_total.values, color=['#FFD700', '#32CD32'])
    ax7.set_title('Sales by Customer Type', fontsize=12, fontweight='bold')
    ax7.set_ylabel('Total Sales')
    ax7.grid(True, alpha=0.3, axis='y')

if 'payment' in insights:
    ax8 = plt.subplot(3, 3, 8)
    payment_total = insights['payment'][('Total', 'sum')]
    ax8.bar(payment_total.index, payment_total.values, 
            color=['#FF6347', '#3CB371', '#FFD700'])
    ax8.set_title('Sales by Payment Method', fontsize=12, fontweight='bold')
    ax8.set_ylabel('Total Sales')
    ax8.grid(True, alpha=0.3, axis='y')

# Overall statistics
ax9 = plt.subplot(3, 3, 9)
ax9.axis('off')
stats_text = f"""
KEY STATISTICS

Total Revenue: ${df['Total'].sum():,.2f}
Total Transactions: {len(df):,}
Average Transaction: ${df['Total'].mean():.2f}

Average Rating: {df['Rating'].mean():.2f}/10
Total Items Sold: {df['Quantity'].sum():,}

Highest Single Sale: ${df['Total'].max():.2f}
Lowest Single Sale: ${df['Total'].min():.2f}
"""
ax9.text(0.1, 0.5, stats_text, fontsize=11, verticalalignment='center',
         family='monospace', bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))

plt.tight_layout()
plt.savefig('plots/21_business_insights_dashboard.png', dpi=300, bbox_inches='tight')
print("✓ Saved: plots/21_business_insights_dashboard.png")
plt.close()

# 4. Generate Final Summary Report
print("\n" + "=" * 80)
print("4. GENERATING FINAL SUMMARY REPORT")
print("=" * 80)

with open('FINAL_SUMMARY_REPORT.txt', 'w') as f:
    f.write("=" * 80 + "\n")
    f.write("SUPERMARKET SALES DATA ANALYTICS - FINAL REPORT\n")
    f.write("=" * 80 + "\n\n")
    
    f.write("1. DATASET OVERVIEW\n")
    f.write("-" * 80 + "\n")
    f.write(f"Total Records: {len(df):,}\n")
    f.write(f"Total Features: {df.shape[1]}\n")
    f.write(f"Date Range: {df['Date'].min()} to {df['Date'].max()}\n\n")
    
    f.write("2. BUSINESS METRICS\n")
    f.write("-" * 80 + "\n")
    f.write(f"Total Revenue: ${df['Total'].sum():,.2f}\n")
    f.write(f"Average Transaction Value: ${df['Total'].mean():.2f}\n")
    f.write(f"Median Transaction Value: ${df['Total'].median():.2f}\n")
    f.write(f"Total Items Sold: {df['Quantity'].sum():,}\n")
    f.write(f"Average Customer Rating: {df['Rating'].mean():.2f}/10\n\n")
    
    f.write("3. MODEL PERFORMANCE COMPARISON\n")
    f.write("-" * 80 + "\n")
    f.write(comparison.to_string(index=False))
    f.write(f"\n\n🏆 BEST MODEL: {best_model['Model']}\n")
    f.write(f"   - Test R² Score: {best_model['Test_R2']:.4f}\n")
    f.write(f"   - Test RMSE: {best_model['Test_RMSE']:.4f}\n")
    f.write(f"   - Test MAE: ${best_model['Test_MAE']:.2f}\n\n")
    
    f.write("4. KEY INSIGHTS\n")
    f.write("-" * 80 + "\n")
    
    if 'branch' in insights:
        top_branch = insights['branch'][('Total', 'sum')].idxmax()
        f.write(f"\n✓ Top Performing Branch: {top_branch}\n")
        f.write(f"  Total Sales: ${insights['branch'].loc[top_branch, ('Total', 'sum')]:,.2f}\n")
    
    if 'product' in insights:
        top_product = insights['product'][('Total', 'sum')].idxmax()
        f.write(f"\n✓ Top Product Line: {top_product}\n")
        f.write(f"  Total Sales: ${insights['product'].loc[top_product, ('Total', 'sum')]:,.2f}\n")
        f.write(f"  Average Rating: {insights['product'].loc[top_product, ('Rating', 'mean')]:.2f}\n")
    
    if 'customer' in insights:
        member_sales = insights['customer'].loc['Member', ('Total', 'sum')] if 'Member' in insights['customer'].index else 0
        normal_sales = insights['customer'].loc['Normal', ('Total', 'sum')] if 'Normal' in insights['customer'].index else 0
        f.write(f"\n✓ Customer Type Analysis:\n")
        f.write(f"  Member Sales: ${member_sales:,.2f}\n")
        f.write(f"  Normal Sales: ${normal_sales:,.2f}\n")
    
    f.write("\n5. RECOMMENDATIONS\n")
    f.write("-" * 80 + "\n")
    f.write("Based on the data analysis, here are key recommendations:\n\n")
    
    if 'branch' in insights:
        worst_branch = insights['branch'][('Total', 'sum')].idxmin()
        f.write(f"✓ Branch {worst_branch} shows lower performance - investigate and improve\n")
    
    if 'product' in insights:
        top_3_products = insights['product'][('Total', 'sum')].head(3)
        f.write(f"✓ Focus on top 3 product lines:\n")
        for product in top_3_products.index:
            f.write(f"  - {product}\n")
    
    f.write(f"\n✓ The {best_model['Model']} model achieves {best_model['Test_R2']:.2%} accuracy\n")
    f.write(f"  in predicting sales, enabling reliable forecasting\n")
    
    f.write("\n6. NEXT STEPS\n")
    f.write("-" * 80 + "\n")
    f.write("✓ Deploy the best-performing model for real-time sales prediction\n")
    f.write("✓ Implement targeted marketing for top-performing product lines\n")
    f.write("✓ Analyze seasonal patterns for better inventory management\n")
    f.write("✓ Investigate customer satisfaction factors affecting ratings\n")
    f.write("✓ Optimize pricing strategies based on model insights\n")

print("✓ Final summary report saved to 'FINAL_SUMMARY_REPORT.txt'")
print("\n✅ Step 6 completed successfully!")
print("\n" + "=" * 80)
print("ALL ANALYSIS STEPS COMPLETED!")
print("=" * 80)
