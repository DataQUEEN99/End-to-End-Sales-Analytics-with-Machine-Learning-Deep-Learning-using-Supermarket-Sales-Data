# Supermarket Sales Data Analytics - Complete Pipeline

## 📊 Project Overview

This project performs a comprehensive data analytics pipeline on a supermarket/retail transaction dataset with **541,910+ records**. The analysis includes data exploration, preprocessing, machine learning models, deep learning models, and business insights visualization.

## 📁 Dataset Information

- **Source**: Online Retail Transaction Data (UCI Machine Learning Repository style)
- **Records**: 541,910 transactions
- **Date Range**: December 2010 to December 2011
- **Features**: Invoice, StockCode, Description, Quantity, InvoiceDate, Price, Customer ID, Country
- **Analyzed Sample**: 100,000 records (for efficient processing)

## 🎯 Analysis Steps Completed

### 1. Data Loading & Exploration ✅
- Loaded 541K+ transaction records
- Displayed first 10 rows and dataset summary
- Analyzed missing values (0.27% in Description, 24.85% in Customer ID)
- Identified 3 numerical and 5 categorical features

### 2. Data Cleaning & Preprocessing ✅
- Created `Total` column (Price × Quantity)
- Handled missing values (filled Description, imputed Customer ID)
- Removed 2,193 negative/zero quantity transactions
- Converted InvoiceDate to datetime format
- Extracted temporal features: Year, Month, Day, Hour, DayOfWeek, Quarter
- Created ProductCategory feature (9 categories)
- Label encoded categorical variables (Country, ProductCategory)
- Created CustomerSegment feature (Low/Medium/High value)
- Standardized numerical features using StandardScaler

### 3. Exploratory Data Analysis (EDA) ✅
Generated 6 comprehensive visualizations:
- **01_distributions.png**: Distribution of Total, Quantity, Price, and Sales over time
- **02_categorical_analysis.png**: Top countries, product categories, hourly/daily sales patterns
- **03_top_products.png**: Top 15 products by quantity and revenue
- **04_correlation_heatmap.png**: Feature correlation matrix
- **05_boxplots.png**: Box plots for Quantity, Price, and Total
- **06_monthly_trends.png**: Monthly sales, quantity, and invoice trends

### 4. Machine Learning Model Training ✅
Trained 3 ML models on 78,245 training samples:

| Model | MAE | RMSE | R² Score |
|-------|-----|------|----------|
| **Random Forest** | **$0.80** | **$30.45** | **0.8489** 🏆 |
| XGBoost | $1.93 | $41.14 | 0.7242 |
| Linear Regression | $11.68 | $51.24 | 0.5721 |

**Best Model**: Random Forest with R² = 0.8489

Visualizations:
- **ml_predictions_comparison.png**: Predicted vs Actual for all 3 models

### 5. Deep Learning Model Training ✅
Built and trained a Feedforward Neural Network:
- **Architecture**: Input → Dense(128, ReLU) → Dropout(0.2) → Dense(64, ReLU) → Dropout(0.2) → Dense(32, ReLU) → Output
- **Training**: 100 epochs with Early Stopping (patience=10)
- **Results**: MAE=$7.19, RMSE=$35.59, R²=0.7936
- **Total Parameters**: 11,905 (46.50 KB)

Visualizations:
- **dl_training_curves.png**: Training/Validation Loss and MAE curves
- **dl_predictions.png**: Predicted vs Actual scatter plot

### 6. Prediction & Visualization ✅
Comprehensive model comparison and business insights:
- **all_models_comparison.png**: Bar charts comparing MAE, RMSE, R² across all 4 models
- **feature_importance.png**: Feature importance for Random Forest and XGBoost
- **business_insights.png**: Top countries, product categories, monthly trends, customer segments

### 7. Summary Report ✅
Generated comprehensive summary report with:
- Dataset statistics and key metrics
- Model performance comparison
- Top 3 feature importances
- 6 actionable business recommendations

## 📈 Key Findings

### Business Metrics
- **Total Revenue**: $2,021,448.05
- **Average Transaction**: $20.67
- **Total Customers**: 4,061
- **Total Products**: 3,606
- **Countries Served**: 38

### Top Performers
- **Best Country**: United Kingdom ($1,718,331 revenue)
- **Best Category**: General products ($1,036,360 revenue)
- **Peak Hour**: 10 AM ($344,896 in sales)
- **Best Day**: Tuesday ($491,271 in sales)

### Model Performance
- **Best Model**: Random Forest (R² = 0.8489)
- **Top Features**: Quantity (70.75%), Price (29.16%), Month (0.04%)

## 💡 Key Recommendations

1. **Customer Focus**: Prioritize UK market and develop loyalty programs for high-value segments
2. **Product Strategy**: Expand General category inventory and optimize seasonal stock levels
3. **Operations**: Schedule more staff at 10 AM and prepare extra inventory for Tuesdays
4. **Pricing**: Implement bundle discounts leveraging Quantity-Price correlation
5. **Predictive Analytics**: Deploy Random Forest model for real-time sales forecasting
6. **Data-Driven Decisions**: Monitor feature importance trends and integrate insights into BI dashboards

## 📂 Project Structure

```
supermarket-analytics/
├── complete_analysis.py          # Main analysis script (all 7 steps)
├── supermarket_data.csv          # Original dataset (541K records)
├── analysis_log.txt              # Complete execution log
├── README.md                     # This file
└── outputs/
    ├── SUMMARY_REPORT.txt        # Comprehensive summary report
    ├── model_metrics.csv         # All model performance metrics
    ├── rf_feature_importance.csv # Random Forest feature importance
    ├── xgb_feature_importance.csv# XGBoost feature importance
    ├── eda/                      # 6 EDA visualizations
    │   ├── 01_distributions.png
    │   ├── 02_categorical_analysis.png
    │   ├── 03_top_products.png
    │   ├── 04_correlation_heatmap.png
    │   ├── 05_boxplots.png
    │   └── 06_monthly_trends.png
    ├── models/                   # Model training results
    │   ├── ml_predictions_comparison.png
    │   ├── dl_training_curves.png
    │   └── dl_predictions.png
    └── predictions/              # Final predictions and insights
        ├── all_models_comparison.png
        ├── feature_importance.png
        ├── business_insights.png
        └── all_predictions.csv   # Test set predictions from all models
```

## 🔧 Technologies Used

- **Python 3.12**
- **Data Processing**: pandas 2.2.3, numpy 1.26.4
- **Visualization**: matplotlib, seaborn
- **Machine Learning**: scikit-learn 1.6.1, xgboost 2.1.3
- **Deep Learning**: TensorFlow 2.20.0, Keras
- **Preprocessing**: StandardScaler, LabelEncoder

## 🚀 How to Run

1. **Install dependencies**:
   ```bash
   pip install pandas numpy matplotlib seaborn scikit-learn xgboost tensorflow
   ```

2. **Run complete analysis**:
   ```bash
   python complete_analysis.py
   ```

3. **View results**:
   - Check `outputs/` directory for all visualizations
   - Read `outputs/SUMMARY_REPORT.txt` for comprehensive findings
   - Review `analysis_log.txt` for execution details

## 📊 Output Files

- **Total Files Generated**: 16
- **Visualizations**: 11 PNG files (high-resolution 300 DPI)
- **Data Files**: 5 CSV files + 1 TXT report

## 📧 Notes

- Analysis performed on 100K sample of 541K records for efficiency
- All random seeds set to 42 for reproducibility
- Deep Learning model trained with Early Stopping to prevent overfitting
- Feature scaling applied using StandardScaler before model training

## 📅 Analysis Date

Generated on: January 10, 2026

---

**Analysis Complete** ✅ | **All Steps Executed Successfully** 🎉
