#!/usr/bin/env python3
"""
Step 3: Exploratory Data Analysis (EDA)
Visualize distributions, correlations, and patterns
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')

# Set style
plt.style.use('seaborn-v0_8-darkgrid')
sns.set_palette("husl")

print("=" * 80)
print("STEP 3: EXPLORATORY DATA ANALYSIS (EDA)")
print("=" * 80)

# Load the dataset
print("\n📂 Loading dataset...")
df = pd.read_csv('supermarket_sales.csv')
print(f"✓ Dataset loaded: {df.shape}")

# Create output directory for plots
import os
os.makedirs('plots', exist_ok=True)

# 1. Distribution of numerical columns
print("\n" + "=" * 80)
print("1. DISTRIBUTION PLOTS - NUMERICAL FEATURES")
print("=" * 80)

numerical_cols = ['Unit price', 'Quantity', 'Tax 5%', 'Total', 'cogs', 'gross income', 'Rating']
numerical_cols = [col for col in numerical_cols if col in df.columns]

fig, axes = plt.subplots(3, 3, figsize=(16, 12))
axes = axes.flatten()

for i, col in enumerate(numerical_cols):
    axes[i].hist(df[col], bins=30, edgecolor='black', alpha=0.7)
    axes[i].set_title(f'Distribution of {col}', fontsize=12, fontweight='bold')
    axes[i].set_xlabel(col)
    axes[i].set_ylabel('Frequency')
    axes[i].grid(True, alpha=0.3)

# Remove empty subplots
for i in range(len(numerical_cols), len(axes)):
    fig.delaxes(axes[i])

plt.tight_layout()
plt.savefig('plots/01_numerical_distributions.png', dpi=300, bbox_inches='tight')
print("✓ Saved: plots/01_numerical_distributions.png")
plt.close()

# 2. Box plots for numerical features
fig, axes = plt.subplots(2, 4, figsize=(18, 10))
axes = axes.flatten()

for i, col in enumerate(numerical_cols):
    axes[i].boxplot(df[col], vert=True, patch_artist=True)
    axes[i].set_title(f'Box Plot: {col}', fontsize=11, fontweight='bold')
    axes[i].set_ylabel(col)
    axes[i].grid(True, alpha=0.3)

for i in range(len(numerical_cols), len(axes)):
    fig.delaxes(axes[i])

plt.tight_layout()
plt.savefig('plots/02_numerical_boxplots.png', dpi=300, bbox_inches='tight')
print("✓ Saved: plots/02_numerical_boxplots.png")
plt.close()

# 3. Categorical features analysis
print("\n" + "=" * 80)
print("2. CATEGORICAL FEATURES ANALYSIS")
print("=" * 80)

categorical_cols = ['Branch', 'City', 'Customer type', 'Gender', 'Product line', 'Payment']
categorical_cols = [col for col in categorical_cols if col in df.columns]

# Bar charts
fig, axes = plt.subplots(2, 3, figsize=(18, 10))
axes = axes.flatten()

for i, col in enumerate(categorical_cols):
    value_counts = df[col].value_counts()
    axes[i].bar(range(len(value_counts)), value_counts.values, color=plt.cm.Set3(range(len(value_counts))))
    axes[i].set_title(f'Distribution of {col}', fontsize=12, fontweight='bold')
    axes[i].set_xlabel(col)
    axes[i].set_ylabel('Count')
    axes[i].set_xticks(range(len(value_counts)))
    axes[i].set_xticklabels(value_counts.index, rotation=45, ha='right')
    axes[i].grid(True, alpha=0.3, axis='y')

plt.tight_layout()
plt.savefig('plots/03_categorical_distributions.png', dpi=300, bbox_inches='tight')
print("✓ Saved: plots/03_categorical_distributions.png")
plt.close()

# 4. Pie charts for key categorical features
fig, axes = plt.subplots(2, 3, figsize=(18, 10))
axes = axes.flatten()

for i, col in enumerate(categorical_cols):
    value_counts = df[col].value_counts()
    axes[i].pie(value_counts.values, labels=value_counts.index, autopct='%1.1f%%', 
                startangle=90, colors=plt.cm.Pastel1(range(len(value_counts))))
    axes[i].set_title(f'{col} Distribution', fontsize=12, fontweight='bold')

plt.tight_layout()
plt.savefig('plots/04_categorical_pie_charts.png', dpi=300, bbox_inches='tight')
print("✓ Saved: plots/04_categorical_pie_charts.png")
plt.close()

# 5. Correlation heatmap
print("\n" + "=" * 80)
print("3. CORRELATION ANALYSIS")
print("=" * 80)

correlation_cols = ['Unit price', 'Quantity', 'Tax 5%', 'Total', 'cogs', 'gross income', 'Rating']
correlation_cols = [col for col in correlation_cols if col in df.columns]

correlation_matrix = df[correlation_cols].corr()

plt.figure(figsize=(12, 10))
sns.heatmap(correlation_matrix, annot=True, fmt='.3f', cmap='coolwarm', 
            center=0, square=True, linewidths=1, cbar_kws={"shrink": 0.8})
plt.title('Correlation Heatmap - Numerical Features', fontsize=16, fontweight='bold', pad=20)
plt.tight_layout()
plt.savefig('plots/05_correlation_heatmap.png', dpi=300, bbox_inches='tight')
print("✓ Saved: plots/05_correlation_heatmap.png")
plt.close()

# 6. Sales by Branch
print("\n" + "=" * 80)
print("4. SALES ANALYSIS BY CATEGORIES")
print("=" * 80)

if 'Branch' in df.columns and 'Total' in df.columns:
    branch_sales = df.groupby('Branch')['Total'].agg(['sum', 'mean', 'count']).reset_index()
    
    fig, axes = plt.subplots(1, 3, figsize=(18, 5))
    
    axes[0].bar(branch_sales['Branch'], branch_sales['sum'], color=['#FF6B6B', '#4ECDC4', '#45B7D1'])
    axes[0].set_title('Total Sales by Branch', fontsize=14, fontweight='bold')
    axes[0].set_xlabel('Branch')
    axes[0].set_ylabel('Total Sales')
    axes[0].grid(True, alpha=0.3, axis='y')
    
    axes[1].bar(branch_sales['Branch'], branch_sales['mean'], color=['#FF6B6B', '#4ECDC4', '#45B7D1'])
    axes[1].set_title('Average Sales by Branch', fontsize=14, fontweight='bold')
    axes[1].set_xlabel('Branch')
    axes[1].set_ylabel('Average Sales')
    axes[1].grid(True, alpha=0.3, axis='y')
    
    axes[2].bar(branch_sales['Branch'], branch_sales['count'], color=['#FF6B6B', '#4ECDC4', '#45B7D1'])
    axes[2].set_title('Number of Transactions by Branch', fontsize=14, fontweight='bold')
    axes[2].set_xlabel('Branch')
    axes[2].set_ylabel('Count')
    axes[2].grid(True, alpha=0.3, axis='y')
    
    plt.tight_layout()
    plt.savefig('plots/06_sales_by_branch.png', dpi=300, bbox_inches='tight')
    print("✓ Saved: plots/06_sales_by_branch.png")
    plt.close()

# 7. Sales by Product Line
if 'Product line' in df.columns:
    product_sales = df.groupby('Product line')['Total'].agg(['sum', 'mean', 'count']).sort_values('sum', ascending=False)
    
    fig, axes = plt.subplots(1, 2, figsize=(16, 6))
    
    axes[0].barh(product_sales.index, product_sales['sum'], color=plt.cm.viridis(np.linspace(0, 1, len(product_sales))))
    axes[0].set_title('Total Sales by Product Line', fontsize=14, fontweight='bold')
    axes[0].set_xlabel('Total Sales')
    axes[0].set_ylabel('Product Line')
    axes[0].grid(True, alpha=0.3, axis='x')
    
    axes[1].barh(product_sales.index, product_sales['mean'], color=plt.cm.plasma(np.linspace(0, 1, len(product_sales))))
    axes[1].set_title('Average Sales by Product Line', fontsize=14, fontweight='bold')
    axes[1].set_xlabel('Average Sales')
    axes[1].set_ylabel('Product Line')
    axes[1].grid(True, alpha=0.3, axis='x')
    
    plt.tight_layout()
    plt.savefig('plots/07_sales_by_product_line.png', dpi=300, bbox_inches='tight')
    print("✓ Saved: plots/07_sales_by_product_line.png")
    plt.close()

# 8. Sales by Gender and Customer Type
if 'Gender' in df.columns and 'Customer type' in df.columns:
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    
    gender_sales = df.groupby('Gender')['Total'].sum()
    axes[0].bar(gender_sales.index, gender_sales.values, color=['#FF69B4', '#4169E1'])
    axes[0].set_title('Total Sales by Gender', fontsize=14, fontweight='bold')
    axes[0].set_xlabel('Gender')
    axes[0].set_ylabel('Total Sales')
    axes[0].grid(True, alpha=0.3, axis='y')
    
    customer_sales = df.groupby('Customer type')['Total'].sum()
    axes[1].bar(customer_sales.index, customer_sales.values, color=['#FFD700', '#32CD32'])
    axes[1].set_title('Total Sales by Customer Type', fontsize=14, fontweight='bold')
    axes[1].set_xlabel('Customer Type')
    axes[1].set_ylabel('Total Sales')
    axes[1].grid(True, alpha=0.3, axis='y')
    
    plt.tight_layout()
    plt.savefig('plots/08_sales_by_gender_customer_type.png', dpi=300, bbox_inches='tight')
    print("✓ Saved: plots/08_sales_by_gender_customer_type.png")
    plt.close()

# 9. Sales by Payment Method
if 'Payment' in df.columns:
    payment_sales = df.groupby('Payment')['Total'].agg(['sum', 'count'])
    
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    
    axes[0].bar(payment_sales.index, payment_sales['sum'], color=['#FF6347', '#3CB371', '#FFD700'])
    axes[0].set_title('Total Sales by Payment Method', fontsize=14, fontweight='bold')
    axes[0].set_xlabel('Payment Method')
    axes[0].set_ylabel('Total Sales')
    axes[0].grid(True, alpha=0.3, axis='y')
    
    axes[1].pie(payment_sales['count'], labels=payment_sales.index, autopct='%1.1f%%', 
                startangle=90, colors=['#FF6347', '#3CB371', '#FFD700'])
    axes[1].set_title('Transaction Count by Payment Method', fontsize=14, fontweight='bold')
    
    plt.tight_layout()
    plt.savefig('plots/09_sales_by_payment_method.png', dpi=300, bbox_inches='tight')
    print("✓ Saved: plots/09_sales_by_payment_method.png")
    plt.close()

# 10. Rating distribution
if 'Rating' in df.columns:
    plt.figure(figsize=(10, 6))
    plt.hist(df['Rating'], bins=20, edgecolor='black', color='skyblue', alpha=0.7)
    plt.axvline(df['Rating'].mean(), color='red', linestyle='--', linewidth=2, label=f'Mean: {df["Rating"].mean():.2f}')
    plt.axvline(df['Rating'].median(), color='green', linestyle='--', linewidth=2, label=f'Median: {df["Rating"].median():.2f}')
    plt.title('Customer Rating Distribution', fontsize=16, fontweight='bold')
    plt.xlabel('Rating')
    plt.ylabel('Frequency')
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig('plots/10_rating_distribution.png', dpi=300, bbox_inches='tight')
    print("✓ Saved: plots/10_rating_distribution.png")
    plt.close()

# Save EDA summary
print("\n" + "=" * 80)
print("SAVING EDA SUMMARY")
print("=" * 80)

with open('eda_report.txt', 'w') as f:
    f.write("=" * 80 + "\n")
    f.write("EXPLORATORY DATA ANALYSIS REPORT\n")
    f.write("=" * 80 + "\n\n")
    
    f.write("1. NUMERICAL FEATURES STATISTICS:\n")
    f.write(df[numerical_cols].describe().to_string())
    f.write("\n\n")
    
    f.write("2. CATEGORICAL FEATURES DISTRIBUTION:\n")
    for col in categorical_cols:
        f.write(f"\n{col}:\n")
        f.write(df[col].value_counts().to_string())
        f.write("\n")
    
    f.write("\n3. CORRELATION INSIGHTS:\n")
    f.write("Top 5 Positive Correlations:\n")
    corr_pairs = correlation_matrix.unstack()
    corr_pairs = corr_pairs[corr_pairs < 1.0].sort_values(ascending=False)
    f.write(corr_pairs.head(5).to_string())
    
    f.write("\n\n4. KEY INSIGHTS:\n")
    f.write(f"- Total Revenue: ${df['Total'].sum():,.2f}\n")
    f.write(f"- Average Transaction Value: ${df['Total'].mean():,.2f}\n")
    f.write(f"- Total Transactions: {len(df):,}\n")
    f.write(f"- Average Rating: {df['Rating'].mean():.2f}\n")
    
    if 'Branch' in df.columns:
        top_branch = df.groupby('Branch')['Total'].sum().idxmax()
        f.write(f"- Top Performing Branch: {top_branch}\n")
    
    if 'Product line' in df.columns:
        top_product = df.groupby('Product line')['Total'].sum().idxmax()
        f.write(f"- Top Product Line: {top_product}\n")

print("✓ EDA report saved to 'eda_report.txt'")
print(f"✓ Total plots generated: 10")
print("\n✅ Step 3 completed successfully!")
